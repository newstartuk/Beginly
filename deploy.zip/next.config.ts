import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  outputFileTracingRoot: __dirname,
  // Cloudflare Pages compatibility
  cleanUrls: true,
  trailingSlash: false,
};

export default nextConfig;
