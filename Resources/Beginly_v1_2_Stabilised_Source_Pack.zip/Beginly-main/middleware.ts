import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

/**
 * Beginly uses Supabase Auth as the single source of truth.
 *
 * The previous middleware trusted custom `nsk_session` / `nsk_is_admin` cookies.
 * Those cookies were not the Supabase session and could break sign-in/sign-out flows.
 * Until `@supabase/ssr` server cookie handling is added, route protection is handled
 * inside protected client pages with `supabase.auth.getUser()` and role checks.
 */
export function middleware(_request: NextRequest) {
  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon|api).*)"],
};
