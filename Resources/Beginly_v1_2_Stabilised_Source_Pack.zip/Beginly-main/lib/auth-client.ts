import { supabase } from "@/lib/supabase";
import type { User as BeginlyUser } from "@/types";

export function displayNameFromAuthUser(user: { email?: string | null; user_metadata?: Record<string, unknown> }): string {
  const metaName = typeof user.user_metadata?.name === "string" ? user.user_metadata.name.trim() : "";
  if (metaName) return metaName;
  return user.email?.split("@")[0] ?? "Beginly user";
}

export async function ensureBeginlyUser(): Promise<BeginlyUser | null> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;

  const name = displayNameFromAuthUser(user);
  const email = user.email ?? "";

  const { data: existing } = await supabase
    .from("users")
    .select("id,name,email,profile_completed,created_at")
    .eq("id", user.id)
    .maybeSingle();

  if (!existing) {
    const { error } = await supabase.from("users").insert({
      id: user.id,
      name,
      email,
      password_hash: "[managed by Supabase Auth]",
      profile_completed: false,
      is_admin: Boolean(user.user_metadata?.is_admin),
    });

    if (error) {
      // Do not block login if the table has not been migrated yet. Protected pages
      // will still rely on Supabase Auth; the database setup screen/report will flag it.
      console.error("Beginly user profile insert failed:", error.message);
    }
  }

  const { data: current } = await supabase
    .from("users")
    .select("id,name,email,profile_completed,created_at")
    .eq("id", user.id)
    .maybeSingle();

  return {
    id: user.id,
    name: current?.name ?? name,
    email: current?.email ?? email,
    passwordHash: "",
    createdAt: current?.created_at ?? new Date().toISOString(),
    profileCompleted: Boolean(current?.profile_completed),
  };
}

export async function isCurrentUserAdmin(): Promise<boolean> {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return false;
  if (user.user_metadata?.is_admin === true) return true;
  const { data } = await supabase.from("users").select("is_admin").eq("id", user.id).maybeSingle();
  return Boolean(data?.is_admin);
}
