"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { getSupabase } from "@/lib/supabase";
import { ensureBeginlyUser } from "@/lib/auth-client";
import { dbProfileToArrivalProfile, generateTasksForProfile } from "@/lib/task-generator";
import type { Database } from "@/types/database";
import type { UserTask } from "@/types";

type Profile = Database["public"]["Tables"]["arrival_profiles"]["Row"];

export interface AuthUser {
  id: string;
  email?: string;
  name?: string;
  isAdmin?: boolean;
}

export interface AuthState {
  user: AuthUser | null;
  profile: Profile | null;
  tasks: UserTask[];
  loading: boolean;
}

export function useAuth(requireAuth = true) {
  const router = useRouter();
  const [state, setState] = useState<AuthState>({ user: null, profile: null, tasks: [], loading: true });

  useEffect(() => {
    let mounted = true;

    async function load() {
      const supabase = getSupabase();
      const { data: { user: sessionUser } } = await supabase.auth.getUser();

      if (!sessionUser) {
        if (requireAuth) { router.push("/login"); return; }
        if (mounted) setState((s) => ({ ...s, loading: false }));
        return;
      }

      const appUser = await ensureBeginlyUser();
      const isAdmin = Boolean(sessionUser.user_metadata?.is_admin);
      const user: AuthUser = {
        id: sessionUser.id,
        email: sessionUser.email,
        name: appUser?.name ?? (sessionUser.user_metadata?.name as string | undefined),
        isAdmin,
      };

      const profileRes = await supabase
        .from("arrival_profiles")
        .select("*")
        .eq("user_id", sessionUser.id)
        .maybeSingle();

      let tasksRes = await supabase
        .from("user_tasks")
        .select("task_id,status,completed_at")
        .eq("user_id", sessionUser.id);

      if ((!tasksRes.data || tasksRes.data.length === 0) && profileRes.data) {
        const generated = generateTasksForProfile(dbProfileToArrivalProfile(profileRes.data));
        if (generated.length) {
          await supabase.from("user_tasks").insert(
            generated.map((task) => ({
              user_id: sessionUser.id,
              task_id: task.taskId,
              status: task.status,
              completed_at: null,
            }))
          );
          tasksRes = await supabase
            .from("user_tasks")
            .select("task_id,status,completed_at")
            .eq("user_id", sessionUser.id);
        }
      }

      if (!mounted) return;

      const tasks: UserTask[] = (tasksRes.data ?? []).map((t): UserTask => ({
        taskId: t.task_id,
        status: t.status as UserTask["status"],
        completedAt: t.completed_at ?? undefined,
      }));

      setState({ user, profile: profileRes.data ?? null, tasks, loading: false });
    }

    load();
    return () => { mounted = false; };
  }, [router, requireAuth]);

  return state;
}
