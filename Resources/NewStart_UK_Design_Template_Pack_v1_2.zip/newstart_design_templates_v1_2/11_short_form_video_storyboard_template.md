# NewStart UK Short-Form Video Storyboard Template

## Format
- Length: 20–45 seconds
- Channels: TikTok, Instagram Reels, YouTube Shorts
- Style: calm, direct, practical, protective
- Presenter: Nia avatar, founder, ambassador, or text-led animation

## Template A: Mistake Alert
**Hook (0–3s):** "Coming to the UK? Do not pay a housing deposit before checking this."

**Problem (3–10s):** "Many new students are pressured to pay quickly before confirming details."

**Checklist (10–30s):**
1. Check provider identity.
2. Save all messages.
3. Confirm the address.
4. Avoid unusual payment methods.
5. Speak to your university/accommodation office if unsure.

**CTA (30–40s):** "Join NewStart UK for your first-90-day settlement checklist."

**Disclaimer:** "General guidance only, not legal or housing advice."

## Template B: First 7 Days
**Hook:** "Your first 7 days in the UK should not be guesswork."
**Steps:** SIM/eSIM, accommodation check, university enrolment, transport, GP planning.
**CTA:** "Build your personalised NewStart roadmap."

## Template C: Nia Explains
**Hook:** "Nia explains: what is a student status letter?"
**Answer:** Plain-English definition + common uses + where to request it.
**CTA:** "Save this for your first month in the UK."
