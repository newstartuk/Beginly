# Canva Template Briefs — NewStart UK

## 1. Instagram/TikTok Cover
- Size: 1080 x 1920
- Background: navy-to-blue gradient
- Top chip: NewStart UK
- Main title: 5–8 words maximum
- Footer: Start right. Settle faster.
- Accent: teal or amber depending on topic

## 2. Instagram Carousel
- Size: 1080 x 1080
- 7 slides
- Slide 1: Hook
- Slides 2–6: practical checklist points
- Slide 7: CTA to waitlist/checklist
- Use Nia tip bubble on one slide

## 3. LinkedIn B2B Post Graphic
- Size: 1200 x 627
- Clean white/navy design
- Headline focused on support burden or onboarding improvement
- Include partner CTA

## 4. Lead Magnet Cover
- Size: A4
- Navy background, white title, blue/teal accent curve
- Include NewStart UK logo, guide title, subtitle and disclaimer footer

## 5. YouTube Thumbnail
- Size: 1280 x 720
- High contrast title
- Nia/compass icon or student arrival image placeholder
- Use amber only for warning topics
