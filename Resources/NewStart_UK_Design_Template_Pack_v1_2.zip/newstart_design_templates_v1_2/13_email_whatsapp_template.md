# NewStart UK Email + WhatsApp Reminder Templates

## Voice
Short, helpful, plain-English, non-alarmist, action-oriented.

## Email Template: Arrival -7 Days
**Subject:** Your UK arrival is 7 days away — here are your next steps

Hi {{first_name}},

Nia here from NewStart UK. Your arrival is coming up, so keep today simple:

1. Confirm your accommodation and first-night plan.
2. Save offline copies of key documents.
3. Check your route from the airport/station to where you will stay.
4. Save emergency contacts.

Open your NewStart roadmap to review your pre-arrival checklist.

General guidance only. NewStart UK does not provide legal, immigration, financial, tax, medical or housing advice.

## WhatsApp Template: First 7 Days
Hi {{first_name}}, your priority today is university check-in and confirming your term-time address. These steps may help with other tasks like bank and GP setup.

Open checklist: {{link}}

## Email Template: Council Tax Reminder
**Subject:** Do not ignore council tax letters

Hi {{first_name}},

If you receive a council tax letter, do not ignore it. As a student, you may need to submit evidence or check your local council process.

Open the guide: {{link}}

General guidance only. Check official/local council guidance for your situation.
