# NewStart UK Design Template Pack v1.2

This pack contains practical, reusable design templates for NewStart UK. It converts the brand strategy into actual template files that can guide UI design, vibe coding, social media production, PDFs, lead magnets, partner one-pagers and Nia/avatar creation.

## Included Templates

1. `01_landing_page_template.html` — homepage/waitlist/partner CTA layout
2. `02_onboarding_flow_template.html` — student arrival profile flow
3. `03_student_dashboard_template.html` — readiness score and dashboard layout
4. `04_checklist_task_template.html` — task detail page layout
5. `05_guidance_article_template.html` — guidance page/article layout
6. `06_safety_alert_template.html` — scam/mistake warning template
7. `07_document_helper_template.html` — Document Helper Lite layout
8. `08_admin_dashboard_template.html` — admin governance console
9. `09_b2b_partner_one_pager_template.html` — university/agent/employer partner one-pager
10. `10_social_carousel_template.html` — visual carousel/story mockup
11. `11_short_form_video_storyboard_template.md` — Reels/TikTok/Shorts storyboard structure
12. `12_pdf_lead_magnet_cover_template.html` — A4 lead magnet cover template
13. `13_email_whatsapp_template.md` — reminder message templates
14. `14_design_prompt_pack.md` — copy-ready design/avatar/UI/social prompts
15. `CANVA_TEMPLATE_BRIEFS.md` — Canva dimensions and structure
16. `FIGMA_FRAME_SPECS.md` — Figma frame plan
17. `brand_tokens.json` — colour/type/token data
18. `newstart-design-system.css` — reusable CSS design system

## How To Use

- Open the HTML files in a browser to preview each template.
- Copy CSS tokens into the app design system or Tailwind configuration.
- Use the Markdown prompt pack when generating new screens, social posts, Nia/avatar concepts or lead magnets.
- Use the Canva and Figma specs to recreate templates inside visual design tools.

## Design Direction

Modern civic-tech + friendly student support + calm fintech-style dashboard.

## Compliance Reminder

NewStart UK provides general settlement guidance, checklist support and signposting. It does not provide legal, immigration, financial, tax, medical or housing advice.
