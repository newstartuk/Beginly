# NewStart UK Design Prompt Pack

## 1. Design System Generation Prompt
Create a modern design system for NewStart UK, a UK newcomer settlement platform starting with international students. The visual direction must be modern civic-tech + friendly student support + calm fintech-style dashboard. Use navy, blue, teal, white, soft green, and amber safety accents. The product must feel trustworthy, calm, practical, warm, professional, and mobile-first. Avoid government impersonation, legal-firm styling, childish visuals, and AI gimmicks. Include colour tokens, typography, buttons, cards, forms, progress indicators, warning states, dashboard widgets, and accessibility guidance.

## 2. Nia Avatar Prompt
Create a semi-illustrated AI guide avatar for Nia — The NewStart Navigator. Nia should feel calm, professional, diverse, friendly, and trustworthy. Do not make the avatar hyper-realistic, glamorous, childish, robotic, or like a government official, doctor, lawyer, immigration officer, real founder, or real student. Nia is an AI-assisted guide for general settlement checklist support.

## 3. UI Screen Generation Prompt
Generate a mobile-first UI screen for NewStart UK using the brand tokens: navy #102A43, blue #2563EB, teal #0F766E, green #10B981, amber #F59E0B, mist background #F8FAFC, and Inter typography. The UI should be card-based, clear, accessible, and trust-first. Include Nia guidance where useful and compliance-safe microcopy.

## 4. Social Media Template Prompt
Create a NewStart UK social media carousel for international students. Topic: {{topic}}. Use a mistake-prevention or first-90-days checklist angle. Tone: calm, practical, protective. Avoid legal/immigration advice. Include a soft disclaimer when the topic is sensitive. Use navy/blue/teal branding and clear slide hierarchy.

## 5. PDF Lead Magnet Prompt
Design a lead magnet PDF cover and internal page style for NewStart UK. Topic: {{topic}}. The design should feel professional, student-friendly, and trustworthy. Include title, subtitle, checklist-style layout, Nia tip callouts, safety warnings, and disclaimer footer.
