# Figma Frame Specs — NewStart UK

## Required Frames
1. Landing Page Desktop — 1440 x variable
2. Landing Page Mobile — 390 x variable
3. Onboarding Mobile — 390 x 844
4. Dashboard Mobile — 390 x 844
5. Checklist Mobile — 390 x 844
6. Task Detail Mobile — 390 x 844
7. Guidance Article Mobile — 390 x variable
8. Safety Centre Mobile — 390 x variable
9. Document Helper Mobile — 390 x 844
10. Admin Dashboard Desktop — 1440 x 1024
11. Social Story Template — 1080 x 1920
12. Carousel Slide Template — 1080 x 1080
13. Lead Magnet Cover — A4

## Auto Layout Rules
- Use 16px mobile side padding.
- Use 24px card radius for major cards.
- Use 12–16px gap between card groups.
- Keep CTAs sticky/visible on long mobile flows where appropriate.
- Warning cards must use amber or red only when necessary.

## Component Library
- Logo mark
- Primary/secondary buttons
- Input/select/textarea
- Checklist card
- Task status badge
- Readiness score card
- Nia tip card
- Safety alert card
- Source review card
- Admin table
