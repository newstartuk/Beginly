# Social Media, Acquisition & Community Growth Engine

_Content-led growth, Hormozi-style loop, channel strategy, and launch calendar_

**Volume:** Volume 5 - Growth, Community & Commercial Engine  
**Priority:** High priority  
**Version:** v1.2

# Purpose
This document turns NewStart UK into a content-led acquisition system. It defines how social content attracts users, builds trust, converts attention, and feeds product intelligence.

# Growth Positioning
NewStart UK owns this content territory:

"We help people coming to the UK avoid confusion, delays, scams, and costly first-90-day mistakes."

# Audience Segments
| Audience | Content Angle |
|---|---|
| Incoming international students | What to do before and after arriving |
| Current international students | Mistakes to fix before they cost money |
| Parents/sponsors | How to help your child settle safely |
| Education agents | Add post-admission support |
| Universities/student unions | Reduce repetitive arrival questions |
| Accommodation providers | Help tenants arrive prepared |
| Skilled workers | UK arrival and admin setup made simpler |

# Content Pillars
| Pillar | Examples |
|---|---|
| First 90 Days | First 7 days checklist, arrival day tasks |
| Mistake Prevention | Housing deposit checks, job scam warnings |
| Document Help | Student status letter, GP forms, council letters |
| Money & Budgeting | First month budget, bank prep |
| Health & GP | Register early, NHS basics |
| Work Readiness | CV, NI number awareness, right-to-work basics |
| City/University Guides | Luton, London, Manchester, university packs |

# NewStart Growth Loop
## Scout
Collect real questions from Reddit, TikTok comments, Facebook groups, WhatsApp groups, support tickets, Google searches, student interviews, university FAQs, and agent questions.

## Architect
Turn questions into checklists, posts, carousels, guides, lead magnets, and app tasks.

## Megaphone
Distribute through TikTok, Instagram, YouTube Shorts, LinkedIn, Facebook groups, WhatsApp broadcast, email, and community partners.

## Closer
Convert attention into waitlist signups, guide downloads, app signups, partner pilot requests, affiliate clicks, or support calls.

## Loop
Use comments and DMs to update FAQs, checklist tasks, guidance pages, and product roadmap.

# Channel Strategy
| Channel | Role |
|---|---|
| TikTok | Awareness and student pain points |
| Instagram | Carousels, stories, community trust |
| YouTube Shorts | Evergreen explainers |
| LinkedIn | B2B universities, agents, employers |
| Facebook Groups | Student/community distribution |
| WhatsApp | Retention and reminders later |
| Email | Waitlist nurturing and lead magnets |

# Weekly Workflow
| Day | Activity |
|---|---|
| Monday | Research questions and pain points |
| Tuesday | Draft 10-20 content ideas |
| Wednesday | Produce videos/carousels |
| Thursday | Schedule and write captions |
| Friday | Engage comments and DMs |
| Saturday | Convert top questions into FAQs/checklist updates |
| Sunday | Review analytics and plan next week |

# Nia on Social Media
Nia can present general tips, reminders, and explainers, but must be disclosed as AI-assisted. Real humans should carry testimonials, founder updates, partner trust, and sensitive stories.

# 30-Day Launch Content Themes
Week 1: Before arrival.
Week 2: Arrival week and safety.
Week 3: Bank, GP, council tax, documents.
Week 4: Jobs, budgeting, housing, 90-day review.

# Social Media Prompt
```text
Create a short-form social post for NewStart UK. Audience: international students coming to the UK. Tone: calm, practical, protective, plain English. Topic: [insert topic]. Include one clear next step and one mistake to avoid. Do not give legal, immigration, financial, tax, medical, or housing advice. End with a soft CTA to join the NewStart UK waitlist or download a checklist.
```

# Final Growth Rule
Social media is not just marketing. It is a listening system that reveals what the product should build next.
