# Master Documentation Architecture

_Document hierarchy, source-of-truth rules, volumes, and update control_

**Volume:** Volume 1 - Strategy & Product Foundation  
**Priority:** Control  
**Version:** v1.2

# Purpose
This document is the control centre for the NewStart UK documentation system. It explains how the 28 documents relate, which documents override others, and how future updates should be managed.

# Pack Structure
The v1.2 documentation pack contains 28 logical documents, grouped into six volumes.

| Volume | Focus | Documents |
|---|---|---|
| Volume 1 | Strategy & Product Foundation | 1-4 |
| Volume 2 | Brand, Trust & Legal Safety | 5-8 |
| Volume 3 | UX, Build & Technical Delivery | 9-15 |
| Volume 4 | AI, Content & Knowledge Operations | 16-19 |
| Volume 5 | Growth, Community & Commercial Engine | 20-23 |
| Volume 6 | Operations, Pilot & Scale | 24-28 |

# Source-of-Truth Hierarchy
When documents conflict, use this order.

| Authority Level | Document | Rule |
|---|---|---|
| 1 | Trust, Safety & Compliance Playbook | Overrides all unsafe, overclaiming, or regulated-advice content |
| 2 | Privacy, Data Protection & GDPR Readiness | Overrides data collection, analytics, AI logging, and B2B reporting conflicts |
| 3 | Product Strategy & MVP Definition | Controls MVP scope and release boundaries |
| 4 | Student Settlement Checklist & Task Logic | Controls intended user journey |
| 5 | Checklist Rules Engine & Seed Data Spec | Controls implementation of checklist logic |
| 6 | Brand, Persona & Trust Identity Bible | Controls tone, persona, and trust positioning |
| 7 | Visual Identity, Design System & UI Copy Guide | Controls visual and interface implementation |
| 8 | Vibe Coding Build Spec | Controls technical construction within scope |

# Cross-Reference Rules
- Marketing documents must obey compliance and product-scope documents.
- AI prompts must obey trust, privacy, and disclaimer documents.
- B2B sales materials must not promise features beyond MVP or roadmap status.
- Analytics must obey privacy and data minimisation rules.
- Social media claims must obey brand, compliance, and source-review standards.
- Partner recommendations must obey affiliate disclosure and verification standards.

# Document Update Policy
Every material update should include:

- version number;
- date;
- owner or editor;
- reason for update;
- affected documents;
- conflict check completed or not;
- next review date.

# Recommended Review Cycle
| Document Type | Review Frequency |
|---|---|
| Compliance, privacy, terms | Before launch and quarterly thereafter |
| Source register | Monthly or whenever official rules change |
| Checklist tasks | Monthly during pilot |
| Social/content strategy | Weekly during launch |
| Build spec and QA | Each sprint |
| Commercial/pricing | Monthly during early validation |
| Strategic blueprint | Quarterly |

# Conflict Resolution Examples
| Conflict | Resolution |
|---|---|
| Social content says "guaranteed council tax exemption" | Compliance wins; change to general guidance and source-backed wording |
| Build spec adds passport upload | Privacy doc wins; postpone until secure storage and policy are ready |
| B2B deck promises partner dashboards in MVP | MVP definition wins; label as roadmap feature |
| AI prompt gives immigration decision | AI governance and compliance override; refuse and signpost |

# Operating Principle
The documentation system should make NewStart UK buildable, safe, marketable, and scalable without allowing ambition to outrun trust or delivery reality.
