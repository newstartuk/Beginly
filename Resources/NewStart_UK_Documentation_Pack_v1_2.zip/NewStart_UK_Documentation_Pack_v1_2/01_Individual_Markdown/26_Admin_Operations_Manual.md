# Admin Operations Manual

_Internal routines for content, users, checklist updates, AI review, partners, and reporting_

**Volume:** Volume 6 - Operations, Pilot & Scale  
**Priority:** Medium priority  
**Version:** v1.2

# Purpose
This document defines how the NewStart UK team should operate the platform after MVP launch.

# Admin Roles
| Role | Permissions |
|---|---|
| Super Admin | All settings, users, content, tasks, partners |
| Content Admin | Guidance pages, city/university packs, FAQs |
| Support Admin | Support tickets and user assistance |
| Partner Admin | Partner records, verification, affiliate links |
| Analyst | Aggregated analytics only |

# Weekly Admin Routine
| Day | Activity |
|---|---|
| Monday | Review user/task analytics |
| Tuesday | Review support tickets and repeated issues |
| Wednesday | Update guidance pages and FAQs |
| Thursday | Review partner leads/complaints |
| Friday | Publish content updates and social insights |
| Sunday | Prepare weekly summary and next priorities |

# Checklist Operations
Admins should:
- review top overdue tasks;
- identify confusing tasks;
- update guidance links;
- deactivate outdated tasks;
- add source review flags;
- avoid changing task IDs once in use.

# Content Operations
- Draft content in approved template.
- Check source register.
- Add disclaimer if sensitive.
- Mark last-reviewed date.
- Publish after review.

# AI Operations
- Review AI helper logs for risk patterns.
- Update prompts when unsafe outputs are found.
- Disable AI feature if repeated critical issues occur.
- Maintain refusal/escalation patterns.

# Partner Operations
- Review new partner applications.
- Run verification checklist.
- Add affiliate disclosure.
- Monitor user complaints.
- Suspend partner if safety risk arises.

# Reporting
Monthly internal report should include:
- users;
- activation rate;
- top tasks;
- top support issues;
- content updates;
- partner performance;
- risk incidents;
- next actions.

# Admin Security
- Use role-based access.
- Remove inactive admins.
- Do not share admin passwords.
- Log sensitive admin actions.
- Use least-privilege permissions.

# Final Admin Rule
The admin system should let NewStart evolve content and operations quickly without needing developers for every update.
