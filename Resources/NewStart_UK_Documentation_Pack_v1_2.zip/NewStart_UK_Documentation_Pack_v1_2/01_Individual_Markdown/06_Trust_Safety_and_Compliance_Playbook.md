# Trust, Safety & Compliance Playbook

_Boundaries for sensitive guidance, disclaimers, escalation, and safety controls_

**Volume:** Volume 2 - Brand, Trust & Legal Safety  
**Priority:** Pre-coding critical  
**Version:** v1.2

# Purpose
This document defines the safety and compliance boundaries for NewStart UK. It must override marketing, AI, content, support, partner, and product decisions whenever user safety or regulated-advice risk is involved.

# Core Rule
NewStart UK provides general settlement guidance, checklist support, document explanation, reminders, and signposting. It does not provide legal, immigration, financial, tax, medical, or housing advice.

# Prohibited Claims
NewStart UK must not claim to:

- guarantee bank account approval;
- guarantee council tax exemption;
- determine immigration eligibility;
- provide legal advice;
- provide immigration advice;
- provide financial or tax advice;
- provide medical diagnosis or treatment;
- represent users in housing disputes;
- act as a government, university, NHS, council, or legal authority;
- submit official forms without explicit user action and appropriate safeguards.

# Required Disclaimer
Use this default disclaimer on sensitive pages:

"NewStart UK provides general settlement guidance, checklist support, document explanation, and signposting. We do not provide legal, immigration, financial, tax, medical, or housing advice. For official or regulated matters, please use official sources or speak to a qualified professional."

# Sensitive Topic Boundaries
| Topic | Allowed | Not Allowed |
|---|---|---|
| Immigration/eVisa/share code | Explain what a share code is and signpost | Decide eligibility or interpret visa conditions as final advice |
| Council tax | Explain general student exemption concepts and signpost | Guarantee exemption or tell user they are definitely liable/not liable |
| GP/NHS | Explain registration and signpost NHS | Diagnose symptoms or give medical advice |
| Banking | Explain document preparation and safety | Recommend a regulated financial product as "best" without disclosure |
| Housing | Explain tenancy terms and scam warnings | Give legal advice or represent disputes |
| Work | Explain general right-to-work awareness | Tell user exactly what work they are legally permitted to do without official verification |

# Escalation Rules
Escalate or signpost when:

- user has a legal deadline;
- user may lose housing;
- user received a formal council/legal letter they do not understand;
- user asks about immigration eligibility or visa conditions;
- user reports exploitation, abuse, threats, or fraud;
- user asks for medical diagnosis;
- user wants to submit an official form;
- AI confidence is low;
- content source is outdated or unclear.

# Scam and Harm Prevention
The app should warn users about:

- fake landlords;
- fake job offers;
- deposit pressure;
- payment requests before verification;
- fake agents;
- fake official websites;
- document phishing;
- people charging to open bank accounts or guarantee jobs;
- requests for bank login details or one-time codes.

# Affiliate and Partner Safety
Affiliate revenue must never compromise user safety.

Rules:
- disclose paid relationships;
- do not rank purely by commission;
- vet partners before promotion;
- keep complaint records;
- remove partners with repeated serious complaints;
- never imply a partner is official unless they are.

# AI Safety Rule
AI can simplify, explain, draft, and signpost. AI must not decide, guarantee, diagnose, represent, or submit sensitive official actions.

# Compliance Review Triggers
Content requires review when it includes:

- visa or right-to-work wording;
- council tax obligations;
- health/medical references;
- financial product references;
- tenancy/legal rights;
- partner claims;
- user data collection;
- AI output used in sensitive workflows.

# Final Safety Principle
If growth, convenience, automation, or revenue conflicts with user safety, user safety wins.
