# Student Settlement Checklist & Task Logic v1.2

_Structured 90-day journey, task fields, reminders, dependencies, and scoring_

**Volume:** Volume 1 - Strategy & Product Foundation  
**Priority:** Pre-coding critical  
**Version:** v1.2

# Purpose
This document converts the student settlement journey into product logic. It is the operational core of the NewStart UK MVP and should feed the database seed data, reminder system, guidance library, and user dashboard.

# Journey Stages
| Stage ID | Stage | Timeline | Purpose |
|---|---|---|---|
| PRE | Before Arrival | Before travel | Prepare documents, accommodation, money, route, and safety plan |
| D1 | Arrival Day | First 24 hours | Safety, contactability, accommodation, rest |
| D7 | First 7 Days | Days 1-7 | University check-in, SIM, transport, orientation, urgent setup |
| D30 | First 30 Days | Days 8-30 | Bank, GP, council tax awareness, documents, budgeting |
| D90 | Days 31-90 | Stability period | Work-readiness, housing stability, wellbeing, community |
| GROW | Ongoing Growth | After day 90 | Career, finance, housing renewal, family and long-term support |

# Task Data Model
Each task should be represented with the following fields.

| Field | Example | Notes |
|---|---|---|
| task_id | STU_BANK_001 | Stable ID for code and analytics |
| title | Prepare for UK bank account setup | User-facing title |
| stage | D30 | Linked to journey stage |
| category | Money | Documents, Accommodation, Health, University, Work, Safety, Local Life, Growth |
| priority | High | Low, Medium, High, Very High |
| required | true | Whether it affects readiness score |
| condition | student AND arrived | Rule that determines visibility |
| dependency_ids | STU_UNI_003 | Tasks that should happen first |
| reminder_trigger | arrival_date + 10 days | Used by reminder system |
| guidance_slug | student-bank-account-prep | Linked guidance article |
| risk_warning | Do not pay anyone to open an account for you | Safety note |
| source_required | true | Needs official/verified source review |
| ai_helper_allowed | true | Can Document Helper assist? |
| escalation_flag | false | Should human review be suggested? |
| admin_editable | true | Can admin update without code? |

# Core Task Categories
| Category | Example Tasks |
|---|---|
| Documents | Passport, visa/eVisa notes, university letter, tenancy, bank letters |
| Accommodation | Contract, deposit, condition photos, utilities, landlord checks |
| Money | Bank account, budget, emergency fund, money transfer |
| Health | GP, NHS basics, medication, wellbeing support |
| University | Enrolment, student ID, status letter, support services |
| Work | NI number, right to work, CV, job search, scams |
| Transport | Airport route, bus/train, student discounts |
| Safety | Emergency contacts, scam warnings, document protection |
| Local Life | Supermarkets, communities, city guide, cultural support |
| Growth | Career, budgeting, confidence, long-term planning |

# Critical Path Logic
The app should not show a flat list only. It should show what unlocks other tasks.

## Bank Account Chain
1. Confirm UK address.
2. Get student status/enrolment letter if required.
3. Prepare passport/visa/eVisa evidence.
4. Compare suitable account options through neutral guidance.
5. Apply through official provider channel.
6. Save confirmation.

## GP Registration Chain
1. Confirm term-time address.
2. Find local GP options.
3. Prepare ID/student proof where requested.
4. Complete registration form.
5. Save confirmation.

## Council Tax Awareness Chain
1. Confirm accommodation type.
2. Confirm full-time student status.
3. Get student status letter if needed.
4. Identify local council.
5. Submit exemption evidence where required.
6. Do not ignore council letters.

## Part-Time Work Chain
1. Understand work conditions from official/university sources.
2. Prepare CV.
3. Learn job scam signs.
4. Get/share right-to-work evidence where needed.
5. Apply for NI number if eligible/needed.
6. Track applications.

# Reminder Schedule
| Timing | Reminder Purpose |
|---|---|
| 30 days before arrival | Start document and accommodation readiness |
| 14 days before arrival | Confirm travel and first-night plan |
| 7 days before arrival | Prepare airport route and emergency contacts |
| 3 days before arrival | Save offline copies of key documents |
| Day 1 | Confirm accommodation and mobile connection |
| Day 3 | Complete university check-in |
| Day 5 | Start bank and GP preparation |
| Day 7 | Review first-week progress |
| Day 14 | Follow up bank, GP, and council tasks |
| Day 30 | Complete settlement stability review |
| Day 60 | Check job, budget, and housing progress |
| Day 90 | Generate settlement review |

# Readiness Score Weights
| Area | Weight |
|---|---:|
| Documents ready | 15% |
| Accommodation stable | 15% |
| University setup complete | 15% |
| Banking/finance setup | 15% |
| Health setup | 10% |
| Council/local admin | 10% |
| Work-readiness | 10% |
| Safety/scam awareness | 5% |
| Community/wellbeing | 5% |

# First Guidance Pages
The first content library should include: Before You Arrive, First 24 Hours, UK Accommodation, Housing Scam Warning, Student Bank Account Preparation, Registering with a GP, NHS Basics, Council Tax Student Exemption Basics, Student Status Letter, SIM/eSIM, UK Transport, First Month Budgeting, Tenancy Documents, Deposit Checks, Part-Time Work Awareness, NI Number Basics, Right-to-Work/Share Code Basics, Job Scam Warning, Emergency Contacts, and First 90-Day Review.
