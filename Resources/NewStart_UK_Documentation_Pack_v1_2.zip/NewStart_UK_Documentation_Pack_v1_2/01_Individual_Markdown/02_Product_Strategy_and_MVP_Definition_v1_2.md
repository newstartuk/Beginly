# Product Strategy & MVP Definition v1.2

_Locked MVP scope, exclusions, release boundaries, and success metrics_

**Volume:** Volume 1 - Strategy & Product Foundation  
**Priority:** Pre-coding critical  
**Version:** v1.2

# Purpose
This document defines the exact MVP scope for NewStart UK. It exists to prevent overbuilding during vibe coding and to make sure the first version is useful, testable, safe, and commercially presentable.

# MVP Name
NewStart UK for International Students.

# MVP Description
A mobile-first web app that helps international students prepare for arrival, complete essential first steps, avoid common mistakes, and settle into the UK within their first 90 days.

# MVP Goals
- Convert scattered settlement information into a personalised roadmap.
- Help users know what to do before arrival, on arrival day, during the first week, first month, and first 90 days.
- Reduce confusion around accommodation, SIM, university check-in, bank preparation, GP registration, council tax awareness, documents, transport, budgeting, and part-time work awareness.
- Create a technical foundation that later supports workers, families, visitors, partners, and AI operations.

# MVP v1 In Scope
| Feature | Description | Priority |
|---|---|---|
| Public landing page | Explain product and collect interest | High |
| Authentication | Email/password sign-up and login | High |
| Onboarding profile | Collect city, university, arrival date, accommodation, nationality, English level | High |
| Personalised roadmap | Generate tasks based on timeline and profile | Very High |
| Checklist dashboard | Show current stage, urgent tasks, progress, readiness score | Very High |
| Task detail pages | Explain what to do, why it matters, and risk warnings | High |
| Guidance library | Basic pages linked to tasks | High |
| Scam and mistake alerts | Static risk cards for housing, jobs, documents, banking, council letters | High |
| Reminder preferences | Email reminder settings and scheduled reminder records | Medium |
| Admin dashboard | Basic checklist/content management | High |
| Document Helper Lite | Controlled AI/plain-English helper as beta or placeholder | Medium |

# MVP v1 Out of Scope
Do not build the following in the first coding pass unless they are later promoted:

- Native iOS or Android app.
- Full storage of passport, visa, bank, or tenancy documents.
- Stripe payments.
- WhatsApp automation.
- Full partner dashboard.
- Full B2B reporting engine.
- Full marketplace transaction flow.
- Auto-submission of official forms.
- Legal, immigration, financial, tax, medical, or housing advice.
- Deep browser automation.
- Fully autonomous job application agent.

# User Profile Fields
| Field | Required | Notes |
|---|---|---|
| Full name | Yes | Can be changed in profile |
| Email | Yes | Used for login and reminders |
| Arrival type | Yes | MVP defaults to international student |
| Arrival status | Yes | Not arrived, arriving soon, arrived |
| Expected/actual arrival date | Yes | Used for stage calculation |
| City | Yes | Used for local guidance |
| University | Yes for student | Used for institution-specific tasks |
| Accommodation type | Yes | Private rental, university accommodation, family/friend, temporary, not secured |
| Nationality | Optional | Useful for feedback and future personalisation |
| English confidence level | Optional | Adjusts content simplicity and helper prompts |
| Interested in part-time work | Optional | Adds jobs/NI/right-to-work awareness tasks |

# MVP User Journey
1. User lands on homepage.
2. User joins waitlist or signs up.
3. User completes onboarding profile.
4. System calculates current journey stage.
5. System generates initial personalised tasks.
6. User sees dashboard with readiness score and urgent tasks.
7. User opens task details and guidance pages.
8. User marks tasks as complete or in progress.
9. User receives email reminders where enabled.
10. Admin updates tasks and guidance without code changes.

# Success Metrics
| Metric | Target for Pilot |
|---|---|
| Waitlist sign-ups | 100+ relevant users or partner leads |
| Onboarding completion | 70%+ of registered users |
| Task engagement | 60%+ mark at least 3 tasks complete |
| Guidance page usage | 50%+ open at least one guidance page |
| Student interviews | 20+ completed |
| Partner conversations | 5+ serious conversations |
| Repeat usage | 30%+ return within 7 days |

# Definition of Done for MVP v1
MVP v1 is complete when a student can sign up, enter an arrival profile, receive a personalised 90-day roadmap, track progress, read guidance, see risk warnings, and when an admin can edit core checklist/content records without changing code.

# Scope Control Rule
If a feature does not help the first student user complete the first 90-day settlement journey, it should be postponed unless it is required for trust, privacy, compliance, or basic operations.
