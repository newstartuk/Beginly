# UX Journey & Screen Map

_User, admin, support, and future partner journeys_

**Volume:** Volume 3 - UX, Build & Technical Delivery  
**Priority:** Pre-coding critical  
**Version:** v1.2

# Purpose
This document maps the product experience screen by screen. It should guide design, frontend build, acceptance testing, and vibe-coding prompts.

# Primary User Journey
## 1. Landing Page
Goal: explain the product and convert the visitor into waitlist or signup.

Key elements:
- headline;
- student-first value proposition;
- problem summary;
- feature preview;
- trust disclaimer;
- waitlist CTA;
- partner CTA.

## 2. Sign Up / Login
Goal: create secure access.

Fields:
- email;
- password;
- confirmation;
- optional Google login later.

## 3. Onboarding Profile
Goal: gather the minimum data needed to generate the roadmap.

Screens:
1. What brings you to the UK?
2. Are you an international student?
3. Arrival date/status.
4. City and university.
5. Accommodation type.
6. Nationality and English confidence, optional.
7. Work interest, optional.
8. Confirmation screen.

## 4. Dashboard
Goal: show what matters today.

Components:
- welcome message;
- current stage badge;
- UK Readiness Score;
- urgent tasks;
- upcoming reminders;
- progress bar;
- scam alert card;
- buttons: Continue checklist, View guidance, Ask Document Helper, Edit profile.

## 5. Checklist Page
Goal: help user work through tasks.

Filters:
- stage;
- category;
- priority;
- status;
- urgent only.

Task card should show:
- task title;
- priority;
- due timing;
- category;
- dependency warning;
- completion toggle.

## 6. Task Detail Page
Goal: explain what to do and why.

Sections:
- task summary;
- why this matters;
- what to prepare;
- common mistakes;
- source/signposting note;
- related guidance;
- mark as complete;
- ask for help.

## 7. Guidance Library
Goal: provide plain-English guidance articles.

Filters:
- documents;
- accommodation;
- money;
- health;
- university;
- work;
- safety;
- local life.

## 8. Document Helper Lite
Goal: simplify non-sensitive text and explain forms.

Flow:
1. User sees disclaimer.
2. User chooses document type.
3. User pastes text or selects sample/template.
4. AI explains in plain English.
5. AI highlights possible missing fields.
6. AI signposts when professional/official help is needed.

## 9. Reminder Settings
Goal: control communication.

Fields:
- email reminders on/off;
- reminder frequency;
- weekly digest;
- urgent reminders;
- marketing emails separate.

## 10. Support / Contact
Goal: route user appropriately.

Categories:
- account issue;
- checklist question;
- document confusion;
- housing concern;
- partner complaint;
- scam concern;
- other.

# Admin Journey
Admin screens:
- admin login;
- dashboard overview;
- user summary;
- checklist template manager;
- task editor;
- guidance content manager;
- city/university pack manager;
- scam alert manager;
- support queue;
- analytics overview;
- partner placeholder manager.

# Future Partner Journey
Partner screens are not MVP v1, but should be designed for future:
- partner login;
- cohort overview;
- anonymised issue trends;
- custom guidance content;
- referral metrics;
- support escalation summaries.

# UX Principles
- Mobile-first.
- One primary action per screen.
- Use plain English.
- Always show what to do next.
- Use warnings carefully, not fearfully.
- Keep sensitive disclaimers visible but not overwhelming.
- Let users complete progress quickly.
