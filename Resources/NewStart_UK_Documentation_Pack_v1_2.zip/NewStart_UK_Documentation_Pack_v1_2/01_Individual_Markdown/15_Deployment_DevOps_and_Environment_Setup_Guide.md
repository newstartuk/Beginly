# Deployment, DevOps & Environment Setup Guide

_Hosting, environment variables, migrations, monitoring, backups, and release checklist_

**Volume:** Volume 3 - UX, Build & Technical Delivery  
**Priority:** Build support  
**Version:** v1.2

# Purpose
This document defines how NewStart UK should be deployed and operated technically during MVP development and pilot.

# Recommended Deployment Stack
| Area | Tool |
|---|---|
| Frontend hosting | Vercel |
| Database/auth | Supabase |
| Email | Resend |
| Repo | GitHub |
| Error logging | Sentry or Vercel logs initially |
| Analytics | Privacy-conscious product analytics |

# Environments
Use at least two environments:

- Development: local machine.
- Production: public pilot deployment.

Preferred later:
- Staging: before production releases.

# Environment Variables
Suggested variables:
```text
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
RESEND_API_KEY=
APP_BASE_URL=
OPENAI_API_KEY=
ADMIN_EMAILS=
```

Rules:
- never commit secrets;
- use Vercel environment variable manager;
- rotate keys if exposed;
- restrict service-role usage to server-only code.

# Database Migrations
- Use SQL migration files.
- Keep schema changes versioned.
- Test migrations on development before production.
- Back up before destructive changes.

# Backup Policy
MVP recommendation:
- daily Supabase backups if available;
- manual export before major migrations;
- store schema migrations in GitHub;
- document restore process.

# Logging
Log:
- auth errors;
- task generation errors;
- email send failures;
- admin changes;
- AI helper errors;
- support ticket creation.

Do not log:
- passwords;
- full document text;
- sensitive personal documents;
- bank/login details;
- unnecessary personal data.

# Release Checklist
Before each production release:
- run tests;
- check environment variables;
- confirm database migrations;
- test signup/login;
- test onboarding;
- test checklist generation;
- test admin access;
- review visible disclaimers;
- test mobile dashboard;
- confirm no debug keys or secrets are exposed.

# Rollback Plan
For MVP:
- keep previous deployment available in Vercel;
- use database backup if migration causes issue;
- disable problematic feature flag where possible;
- notify users if issue affects data or safety.

# Security Notes
- Use Supabase row-level security.
- Separate admin and user permissions.
- Avoid storing sensitive documents in MVP.
- Protect admin routes server-side.
- Use HTTPS only.
