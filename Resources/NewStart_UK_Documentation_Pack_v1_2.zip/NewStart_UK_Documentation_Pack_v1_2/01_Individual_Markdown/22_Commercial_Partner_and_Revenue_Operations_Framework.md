# Commercial, Partner & Revenue Operations Framework

_B2C, B2B, affiliate, premium support, partner verification, and pricing logic_

**Volume:** Volume 5 - Growth, Community & Commercial Engine  
**Priority:** High priority  
**Version:** v1.2

# Purpose
This document turns NewStart UK monetisation into an operating model.

# Revenue Strategy
NewStart UK should use layered revenue:

1. B2C plans.
2. Premium human support.
3. B2B pilot packages.
4. B2B2C institutional distribution.
5. Affiliate/referral revenue.
6. Verified partner marketplace.
7. White-label or co-branded portals later.

# B2C Pricing Draft
| Plan | Price | Features |
|---|---:|---|
| Free | £0 | Basic checklist and guidance |
| Starter | £9.99 | Personalised roadmap and reminders |
| Plus | £24.99 | Document helper, city guide, mistake alerts |
| Premium | £49-£99 | Human support/review session |
| Family Pack | £79-£149 | Multi-person guidance later |

# B2B Pilot Pricing Draft
| Offer | Price |
|---|---:|
| Small partner pilot | £500-£1,000 setup + revenue share |
| Student onboarding pilot | £2,500 setup + £5 per active student |
| Annual licence later | £5,000-£50,000 depending on size |
| White-label later | Custom |

# Premium Support Services
Potential services:
- student arrival planning call;
- document-readiness review;
- housing-readiness review;
- family relocation planning;
- employer relocation support.

# Affiliate Categories
| Category | Revenue Type | Risk Level |
|---|---|---|
| SIM/eSIM | Commission | Low |
| Money transfer | Affiliate | Medium |
| Insurance | Affiliate | Medium |
| Airport pickup | Commission | Medium |
| Temporary accommodation | Commission/lead | High |
| Student storage | Commission | Low |
| CV/job support | Referral | Medium |
| Legal/immigration firms | Referral only | High |
| Recruitment agencies | Lead/referral | High |

# Affiliate Rules
- disclose paid relationships;
- do not rank purely by commission;
- allow users to choose alternatives;
- vet partners;
- track complaints;
- remove unsafe partners.

# Partner Verification
Partner checks:
- company registration;
- website/contact details;
- pricing transparency;
- refund policy;
- complaints process;
- online reputation;
- safeguarding concerns;
- service suitability;
- risk category;
- review date.

# Revenue Operations Workflow
1. Identify partner category.
2. Run verification checklist.
3. Agree commercial terms.
4. Create partner listing.
5. Add disclosure.
6. Track clicks/leads/conversions.
7. Monitor complaints.
8. Review partner quarterly.

# Commercial Guardrail
If a partner offer could harm user trust, reject it even if commission is attractive.
