# B2B Sales, Proposal & Account Management Playbook

_University, agent, employer, accommodation, and partner sales workflows_

**Volume:** Volume 6 - Operations, Pilot & Scale  
**Priority:** High priority  
**Version:** v1.2

# Purpose
This document helps NewStart UK sell to institutions without overpromising. It supports universities, education agents, accommodation providers, employers, care recruiters, and community organisations.

# B2B Positioning
NewStart UK helps organisations reduce repetitive newcomer support questions by giving users a structured, personalised onboarding journey.

# Target B2B Segments
| Segment | Pain | Offer |
|---|---|---|
| Universities | Repetitive student arrival questions | Student onboarding pilot |
| Education agents | Lack of after-admission support | Post-admission support package |
| Accommodation providers | Tenant confusion, documents, arrival issues | Tenant onboarding assistant |
| Employers | Overseas worker relocation friction | Worker onboarding package later |
| Care recruiters | Overseas staff settlement | Health/care worker journey later |
| Community organisations | Informal newcomer support burden | Structured guidance portal |

# Discovery Questions
- How many newcomers do you support yearly?
- What questions repeat most often?
- Which arrival tasks cause delays or complaints?
- How do you currently communicate checklists?
- Would reminders reduce support workload?
- What data/insights would help your team?
- What would make you trust a pilot?
- What budget or payment model is realistic?

# Pilot Proposal Structure
1. Executive summary.
2. Partner problem.
3. NewStart solution.
4. Pilot scope.
5. User journey.
6. Partner benefits.
7. Data/privacy boundaries.
8. Timeline.
9. Pricing.
10. Success metrics.
11. Next steps.

# Pilot Offer
Suggested student pilot:

- setup: £2,500;
- active user fee: £5 per student;
- pilot duration: 60-90 days;
- includes: branded access link, student onboarding roadmap, reminders, guidance, anonymised report.

Small partner option:
- setup: £500-£1,000;
- revenue share or per-user pricing;
- limited reporting.

# Sales Claim Boundaries
Do not say:
- "We guarantee fewer complaints."
- "We provide immigration advice."
- "We solve all student settlement issues."
- "We replace your student support team."

Say:
- "We help structure and reduce repetitive arrival confusion."
- "We provide general settlement guidance and signposting."
- "We can support your existing onboarding process."
- "We provide anonymised insight reports where privacy rules permit."

# Follow-Up Email Template
```text
Subject: Structured arrival support for your international students

Hello [Name],

Thank you for discussing the support challenges faced by incoming students. NewStart UK helps students understand their first steps through personalised checklists, reminders, local guidance, and mistake-prevention alerts.

For a pilot, we can support a defined cohort with a 90-day onboarding roadmap and provide anonymised insight into common student confusion points.

Would you be open to reviewing a short pilot proposal for [intake/cohort]?

Best regards,
[Name]
```

# Account Management Routine
For active partners:
- monthly check-in;
- report common issues;
- review content updates;
- discuss user feedback;
- identify next cohort;
- review renewal/expansion.

# Final Sales Rule
Sell the real value: clarity, structure, support, and insight. Do not sell fantasy automation or overstate what the MVP can do.
