# Strategic Blueprint v1.2

_Vision, positioning, market logic, expansion path, and strategic guardrails_

**Volume:** Volume 1 - Strategy & Product Foundation  
**Priority:** Foundation  
**Version:** v1.2

# Purpose
This document is the parent strategic narrative for NewStart UK. It defines what NewStart UK is, why it matters, who it serves first, how it expands, and what must remain true as the product moves from idea to MVP to platform.

# Executive Summary
NewStart UK is an AI-assisted UK arrival and settlement platform that helps newcomers settle faster, avoid costly mistakes, and complete essential first steps through personalised roadmaps, reminders, document guidance, local support, and trusted service recommendations.

The launch focus is international students because their first 90 days are urgent, structured, emotionally stressful, and commercially reachable through universities, education agents, student communities, accommodation providers, and faith/community networks. The long-term opportunity is wider: NewStart UK can serve skilled workers, health and care workers, dependants, families, visitors, employers, universities, agents, accommodation providers, relocation partners, charities, and community organisations.

# Core Strategic Position
NewStart UK should not be framed as a student-only website. It should be framed as a UK newcomer onboarding platform, with international students as the first supported vertical.

## One-line Positioning
NewStart UK helps people moving to the UK settle faster, avoid costly mistakes, and complete essential first steps through personalised checklists, reminders, AI document support, verified local guidance, and partner-backed onboarding services.

## Strategic Principle
Start with students. Build for newcomers. Scale through institutions.

# Problem Definition
People arriving in the UK face a dense set of early tasks: accommodation, banking, GP registration, transport, SIM setup, council tax awareness, work-readiness, documents, budgeting, local safety, and community integration. The issue is not only lack of information. The issue is that information is scattered, generic, not sequenced, and often discovered only after a mistake has occurred.

NewStart UK converts scattered settlement information into a guided settlement journey.

# Strategic Product Pillars
| Pillar | Meaning | Product Expression |
|---|---|---|
| Plan | Prepare before arrival | Pre-arrival checklist, document readiness, travel plan |
| Settle | Complete first steps | 90-day checklist, reminders, progress tracking |
| Protect | Avoid costly mistakes | Scam alerts, mistake-prevention warnings, verified partners |
| Understand | Make documents clearer | Document Helper Lite, plain-English guidance, key-term explanation |
| Connect | Find safe support | Local guidance, partner marketplace, community links |
| Grow | Move beyond survival | Jobs, budgeting, housing stability, career and family support |

# Target Segment Roadmap
| Phase | Segment | Primary Need | Commercial Route |
|---|---|---|---|
| 1 | International students | First 90-day settlement | B2C, universities, agents, student communities |
| 2 | Skilled workers | Work, NI, GP, housing, right-to-work support | Employers, recruiters, B2C |
| 3 | Health and care workers | Relocation, DBS, housing, local adaptation | Care agencies, NHS recruitment partners |
| 4 | Dependants and families | GP, schools, household setup, local integration | B2C, employers, community partners |
| 5 | Visitors and short-stay arrivals | Travel, safety, transport, accommodation | B2C, travel/service partners |
| 6 | B2B partners | Onboarding infrastructure | Licensing, pilots, white-label, managed service |

# Commercial Logic
NewStart UK should use layered monetisation rather than a single revenue stream.

- B2C plans for newcomers.
- Premium human support sessions.
- B2B licensing for universities, employers, agents, accommodation providers, and relocation partners.
- B2B2C distribution through institutions that give users access.
- Affiliate and referral revenue from trusted settlement-related services.
- White-label or co-branded onboarding portals for institutional clients.
- Anonymised insight reports where privacy rules and consent permit.

# Competitive Advantage
The moat is not general information. The moat is structured personalisation and trust.

Key advantages:
- personalisation by arrival type, city, university, accommodation, and timeline;
- task dependency logic that tells users what to do first;
- scam and mistake-prevention intelligence;
- city and institution-specific guidance packs;
- transparent AI support with safe boundaries;
- verified partner marketplace;
- admin and partner dashboards;
- anonymised insights for institutions.

# Strategic Guardrails
| Guardrail | Meaning |
|---|---|
| Brand broad, MVP narrow | Public positioning can be broad, but MVP v1 must stay student-focused |
| Guidance, not regulated advice | The product explains and signposts; it does not act as lawyer, immigration adviser, doctor, financial adviser, or housing representative |
| Trust before monetisation | Affiliate revenue must never compromise user safety |
| AI assists, humans decide | AI can prepare, simplify, draft, triage, and explain; final actions remain user or human-led |
| Privacy by default | Collect only what is needed, minimise sensitive data, anonymise B2B reporting |

# Strategic Verdict
NewStart UK should start as a student settlement assistant, grow into a newcomer onboarding platform, and mature into AI-powered settlement infrastructure for the UK mobility ecosystem.
