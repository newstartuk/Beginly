# Content & Knowledge Base Operations Manual

_Guidance pages, city packs, university packs, review workflows, and content templates_

**Volume:** Volume 4 - AI, Content & Knowledge Operations  
**Priority:** Operations  
**Version:** v1.2

# Purpose
This document defines how NewStart UK creates, reviews, updates, and manages its knowledge base.

# Content Principle
Content should be plain-English, practical, source-aware, and task-linked. Each guidance page should help the user complete a specific step or avoid a specific mistake.

# Content Types
| Type | Purpose |
|---|---|
| Guidance page | Explains a specific task |
| City pack | Local transport, services, communities, warnings |
| University pack | Institution-specific onboarding steps |
| FAQ | Answers repeated questions |
| Scam alert | Warns about common risks |
| Email reminder | Prompts timely action |
| Lead magnet | Converts social/SEO traffic |
| Partner content | Explains approved partner offers |

# Guidance Page Template
Each guidance page should include:

1. What this is.
2. Why it matters.
3. What to prepare.
4. Steps to take.
5. Common mistakes.
6. Safety warning where relevant.
7. Official/source signposting.
8. Disclaimer.
9. Related checklist tasks.
10. Last reviewed date.

# City Pack Template
- city overview;
- airport/transport route notes;
- local transport options;
- student/community areas;
- GP/local health signposting;
- council/local admin signposting;
- accommodation cautions;
- supermarkets/pharmacies;
- emergency support;
- local student/community groups.

# University Pack Template
- enrolment/check-in steps;
- international office links;
- student status letter process;
- accommodation office/support;
- student union;
- wellbeing support;
- careers service;
- key arrival dates;
- official source links.

# Content Review Workflow
1. Draft content.
2. Check brand voice.
3. Check compliance boundaries.
4. Add source/signposting.
5. Add disclaimer where sensitive.
6. Human review.
7. Publish.
8. Set review date.

# Content Update Triggers
Update content when:
- official source changes;
- users report confusion;
- support tickets repeat same issue;
- partner provides verified update;
- social comments reveal a new pain point;
- content has not been reviewed within its review cycle.

# First 20 Content Pages
Start with the first 20 guidance pages from the checklist document: pre-arrival, first 24 hours, accommodation, housing scams, bank prep, GP, NHS basics, council tax, student status letter, SIM/eSIM, transport, budgeting, tenancy, deposit checks, part-time work, NI number, right-to-work/share code, job scams, emergency contacts, and 90-day review.

# Content Quality Rule
Every page should answer: What should the user do next, what should they avoid, and where should they go for official or qualified help?
