# Ambassador, Referral & Community Programme

_Student ambassadors, referral loops, community rules, and testimonial strategy_

**Volume:** Volume 5 - Growth, Community & Commercial Engine  
**Priority:** Medium priority  
**Version:** v1.2

# Purpose
This document defines how NewStart UK can grow through real people, communities, referrals, and trust-based advocacy.

# Programme Principle
AI can scale content, but real humans build trust. Ambassadors should extend NewStart UK into universities, cities, and communities without giving regulated advice.

# Ambassador Types
| Type | Role |
|---|---|
| Student ambassador | Share checklists, collect questions, create content |
| City ambassador | Provide local insights and content ideas |
| University ambassador | Help tailor university-specific packs |
| Community ambassador | Connect faith/cultural/community groups |
| Partner ambassador | Represent approved institutions or organisations |

# Ambassador Responsibilities
- share official NewStart content;
- collect newcomer questions;
- refer users to waitlist/app;
- report common issues;
- help validate city/university packs;
- appear in approved testimonials or content.

# Ambassador Boundaries
Ambassadors must not:
- give legal, immigration, medical, financial, tax, or housing advice;
- pretend to be official representatives of government/university unless authorised;
- collect sensitive documents;
- charge users privately using the NewStart name;
- promote unverified partners;
- guarantee outcomes.

# Referral Programme Ideas
| Referral Action | Reward Idea |
|---|---|
| Refer a student | Free Plus access or discount |
| Refer 5 students | Premium guide/session discount |
| Refer partner lead | Commission or referral bonus after conversion |
| Ambassador monthly activity | Stipend, certificate, public recognition |

# Community Channels
Potential channels:
- WhatsApp broadcast;
- Telegram group/channel;
- Instagram community;
- Facebook groups;
- email newsletter;
- university society partnerships.

# Community Moderation Rules
- no fake jobs;
- no unverified accommodation offers;
- no payment requests;
- no document collection;
- no harassment;
- no regulated advice;
- no spam links;
- report scams quickly.

# Testimonial Collection
Only use testimonials with consent. Avoid fake or AI-generated testimonials. Collect:
- name or initials;
- city/university if consented;
- problem before NewStart;
- result after using NewStart;
- permission scope.

# Community Success Metrics
- referrals;
- ambassador signups;
- questions collected;
- city/university pack contributions;
- waitlist conversions;
- content shares;
- partner introductions.

# Final Community Rule
Community must make newcomers safer and clearer, not expose them to more scams.
