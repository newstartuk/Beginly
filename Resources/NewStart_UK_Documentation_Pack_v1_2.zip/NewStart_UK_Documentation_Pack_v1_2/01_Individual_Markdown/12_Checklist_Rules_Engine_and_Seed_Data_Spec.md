# Checklist Rules Engine & Seed Data Spec

_Task-generation conditions, sample JSON, readiness formula, and fallback logic_

**Volume:** Volume 3 - UX, Build & Technical Delivery  
**Priority:** Pre-coding critical  
**Version:** v1.2

# Purpose
This document converts the 90-day checklist into machine-readable rules and seed data for the MVP.

# Rules Engine Inputs
| Input | Source | Use |
|---|---|---|
| arrival_type | Onboarding | MVP defaults to student |
| arrival_status | Onboarding | Determines stage |
| arrival_date | Onboarding | Calculates timeline |
| city | Onboarding | Local guidance |
| university | Onboarding | University tasks |
| accommodation_type | Onboarding | Housing tasks and warnings |
| english_level | Onboarding | Content simplicity |
| interested_in_work | Onboarding | Work/NI/right-to-work tasks |

# Stage Calculation
If user has not arrived, stage = PRE.
If arrival date is today or 1 day ago, stage = D1.
If days since arrival is 1-7, stage = D7.
If days since arrival is 8-30, stage = D30.
If days since arrival is 31-90, stage = D90.
If days since arrival is greater than 90, stage = GROW.

# Task Visibility Logic
A task should appear when:

- user type matches;
- stage is current or earlier incomplete;
- conditions match profile;
- dependencies are completed or task is marked as preparatory;
- task is active.

# Sample Task JSON
```json
{
  "task_id": "STU_HEALTH_001",
  "title": "Register with a GP near your university or term-time address",
  "stage": "D30",
  "category": "Health",
  "priority": "Very High",
  "required": true,
  "condition": "arrival_type == 'student' && days_since_arrival >= 1",
  "dependency_ids": ["STU_PROFILE_001"],
  "reminder_trigger": "arrival_date + 10 days",
  "guidance_slug": "how-to-register-with-a-gp",
  "risk_warning": "Do not wait until you are ill before learning how to access GP services.",
  "source_required": true,
  "ai_helper_allowed": true,
  "escalation_flag": false,
  "admin_editable": true
}
```

# Seed Task Minimum Set
MVP should seed at least 40 tasks across:

- pre-arrival;
- arrival day;
- first week;
- first month;
- days 31-90;
- ongoing growth.

# Required Starter Tasks
| Task ID | Title | Stage | Category |
|---|---|---|---|
| STU_PRE_001 | Confirm university enrolment instructions | PRE | University |
| STU_PRE_002 | Confirm accommodation and first-night plan | PRE | Accommodation |
| STU_PRE_003 | Prepare key document copies | PRE | Documents |
| STU_PRE_004 | Plan airport-to-accommodation route | PRE | Transport |
| STU_D1_001 | Confirm arrival safely | D1 | Safety |
| STU_D1_002 | Reach accommodation safely | D1 | Accommodation |
| STU_D7_001 | Complete university check-in | D7 | University |
| STU_D7_002 | Set up UK SIM/eSIM | D7 | Local Life |
| STU_D30_001 | Prepare for bank account setup | D30 | Money |
| STU_D30_002 | Register with a GP | D30 | Health |
| STU_D30_003 | Understand council tax student exemption basics | D30 | Local Admin |
| STU_D90_001 | Review budget after first month | D90 | Money |
| STU_D90_002 | Complete 90-day settlement review | D90 | Growth |

# Readiness Score Formula
Each required task contributes to category completion. Category completion is multiplied by category weight.

Pseudo-formula:
```text
readiness_score = sum(category_completion_percentage * category_weight)
```

# Fallback Behaviour
If user has missing profile data:
- show general student checklist;
- ask user to complete missing fields;
- avoid hiding safety-critical tasks;
- use default UK-wide guidance.

# Admin Controls
Admins should be able to:
- activate/deactivate a task;
- change priority;
- change stage;
- update guidance slug;
- add risk warning;
- mark source review needed;
- set AI helper allowed or not.

# Rule Safety
Any task involving legal/immigration/financial/tax/medical/housing implications must include disclaimer and source-required flag.
