# Analytics, Events & Product Metrics Spec

_Event tracking, privacy-safe metrics, dashboards, and product intelligence_

**Volume:** Volume 3 - UX, Build & Technical Delivery  
**Priority:** Build support  
**Version:** v1.2

# Purpose
This document defines what NewStart UK should measure to improve the product, validate demand, support B2B reporting, and feed the social/content engine.

# Analytics Principle
Track useful behaviour, not unnecessary personal detail. Analytics must obey privacy and data minimisation rules.

# Core Events
| Event | Trigger | Purpose |
|---|---|---|
| landing_viewed | Page visit | Measure interest |
| waitlist_submitted | Waitlist form completed | Demand validation |
| signup_started | User begins registration | Funnel tracking |
| signup_completed | Account created | Conversion tracking |
| onboarding_started | Profile flow begins | Onboarding funnel |
| onboarding_completed | Profile saved | Activation metric |
| checklist_generated | User tasks created | Core product activation |
| dashboard_viewed | Dashboard opened | Repeat engagement |
| task_opened | Task detail viewed | Task interest |
| task_completed | User completes task | Progress tracking |
| guide_viewed | Guidance article opened | Content value |
| reminder_clicked | Email link clicked | Reminder usefulness |
| document_helper_used | AI/helper opened | AI demand |
| support_ticket_created | User asks for support | Pain point tracking |
| partner_enquiry_submitted | Partner form completed | B2B demand |

# Product Metrics
| Metric | Why It Matters |
|---|---|
| Onboarding completion rate | Shows whether setup is too long or confusing |
| Task completion rate | Shows whether users act on guidance |
| Top incomplete tasks | Identifies confusion or friction |
| Guide views by category | Shows content demand |
| Return within 7 days | Shows product stickiness |
| Reminder click rate | Shows reminder value |
| Support categories | Reveals user pain points |
| City/university clusters | Helps decide content expansion |

# B2B Reporting Metrics
Default B2B reporting should be anonymised and aggregated.

Possible B2B metrics:
- percentage of cohort completing first-week tasks;
- most delayed tasks;
- top confusion categories;
- guidance pages most used;
- common support questions;
- readiness score range;
- city/accommodation issue trends.

# Content Intelligence Loop
User behaviour should feed content operations.

Examples:
- task with low completion becomes explainer content;
- repeated support question becomes FAQ;
- top searched guide becomes social video;
- city cluster becomes city pack;
- partner demand becomes B2B pitch angle.

# Privacy Controls
- Avoid storing unnecessary raw text.
- Use aggregated reporting for partners.
- Do not expose individual user progress by default.
- Respect opt-outs where relevant.
- Keep analytics cookie/consent approach aligned with policy.

# MVP Dashboard
Admin analytics v1 should show:
- total users;
- onboarding completion;
- task completion summary;
- top overdue tasks;
- top guide pages;
- support ticket categories;
- city/university counts;
- waitlist/partner enquiry counts.
