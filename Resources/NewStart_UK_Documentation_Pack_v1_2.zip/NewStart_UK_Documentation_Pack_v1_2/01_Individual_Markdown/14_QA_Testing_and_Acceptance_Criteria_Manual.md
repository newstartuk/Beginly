# QA, Testing & Acceptance Criteria Manual

_Feature tests, compliance tests, AI tests, mobile checks, and release gates_

**Volume:** Volume 3 - UX, Build & Technical Delivery  
**Priority:** Pre-coding critical  
**Version:** v1.2

# Purpose
This document defines the tests NewStart UK must pass before release. It is especially important because vibe-coded applications can look polished while hiding logic, privacy, and edge-case failures.

# QA Principle
A feature is not complete because it appears on screen. It is complete when it works correctly, safely, responsively, and within the approved MVP scope.

# Core Test Areas
## Authentication
- User can sign up.
- User can log in.
- User can log out.
- Protected pages block unauthenticated users.
- Admin pages block non-admin users.

## Onboarding
- Required fields validate correctly.
- Arrival date accepts valid dates.
- User can edit profile later.
- Missing optional fields do not break task generation.

## Checklist Generation
- Pre-arrival users receive PRE tasks.
- Newly arrived users receive D1/D7 tasks.
- Arrived 8-30 days users receive D30 tasks.
- Private rental users receive tenancy/deposit warnings.
- Work-interested users receive work-readiness tasks.
- Task dependencies display correctly.

## Dashboard
- Readiness score displays.
- Progress updates after task completion.
- Urgent tasks are prioritised.
- Empty states are helpful.

## Guidance Library
- Every linked guide opens.
- Sensitive guides show disclaimers.
- Source-needed flags are visible to admin.

## Admin
- Admin can create/edit/deactivate tasks.
- Admin can edit guidance pages.
- Admin changes do not corrupt user task records.
- Non-admin users cannot access admin routes.

## AI / Document Helper
- AI displays disclaimer.
- AI refuses regulated advice.
- AI asks user not to paste highly sensitive data where appropriate.
- AI escalates legal/immigration/medical/financial/housing decisions.

## Mobile and Accessibility
- Screens work on common mobile widths.
- Buttons are tappable.
- Text is readable.
- Forms have labels.
- Warning states are not colour-only.

# Compliance Tests
Every sensitive page must pass:
- disclaimer visible;
- no guaranteed outcome wording;
- no official-authority impersonation;
- source/signposting note included;
- escalation route included where needed.

# Release Gate
Do not release publicly unless:
- critical auth flows pass;
- checklist generation passes core scenarios;
- admin access is protected;
- mobile dashboard is usable;
- privacy-sensitive features are disabled or controlled;
- disclaimers are visible;
- no out-of-scope claims appear on landing page or product screens.

# Bug Severity
| Severity | Definition | Action |
|---|---|---|
| Critical | Data leak, auth bypass, harmful guidance, payment issue | Block release |
| High | Broken onboarding, wrong task generation, admin bug | Fix before release |
| Medium | UI issue, confusing copy, non-critical flow friction | Fix before pilot if possible |
| Low | Cosmetic or minor content issue | Log and schedule |
