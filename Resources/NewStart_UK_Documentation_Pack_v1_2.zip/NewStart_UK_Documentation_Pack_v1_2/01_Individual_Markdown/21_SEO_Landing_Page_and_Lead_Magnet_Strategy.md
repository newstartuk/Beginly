# SEO, Landing Page & Lead Magnet Strategy

_Search content, conversion pages, downloadable assets, and waitlist funnel_

**Volume:** Volume 5 - Growth, Community & Commercial Engine  
**Priority:** Medium priority  
**Version:** v1.2

# Purpose
This document defines how NewStart UK should attract search traffic, convert visitors, and build an early waitlist through useful lead magnets.

# SEO Positioning
NewStart UK should rank for practical settlement questions, not broad inspirational topics.

Content clusters:
- international student arrival checklist;
- first 90 days in the UK;
- UK student bank account preparation;
- GP registration for students;
- council tax student exemption basics;
- housing scam warning for students;
- UK arrival budget planner;
- city/university arrival packs.

# Landing Page Structure
The main landing page should include:

1. Hero headline.
2. Problem statement.
3. Solution summary.
4. How it works.
5. Key features.
6. Who it is for.
7. Student benefits.
8. Partner benefits.
9. AI support disclosure.
10. Pricing teaser.
11. Waitlist CTA.
12. Partner CTA.
13. Trust/safety disclaimer.

# Lead Magnets
Start with downloadable or interactive assets:

- UK First 7 Days Checklist.
- International Student 90-Day Roadmap.
- Housing Scam Warning Checklist.
- Bank Account Document Prep Checklist.
- GP Registration Starter Guide.
- Council Tax Letter Explainer.
- UK Arrival Budget Planner.
- Student Job Scam Warning Sheet.
- City Arrival Packs.
- Parent/Sponsor Guide.

# Lead Magnet Form Fields
- name;
- email;
- arrival type;
- city;
- university if student;
- expected arrival date;
- biggest concern;
- consent to receive updates.

# SEO Page Template
Each SEO page should include:
- plain-English intro;
- who it is for;
- step-by-step guidance;
- mistakes to avoid;
- checklist download CTA;
- source/signposting note;
- disclaimer;
- related pages.

# Conversion Funnel
1. Social or search visitor lands on useful content.
2. Visitor downloads checklist or joins waitlist.
3. Email sequence sends practical value.
4. User signs up for app access.
5. User completes onboarding.
6. User gets personalised checklist.
7. User may upgrade or refer others.

# Landing Page Copy Prompt
```text
Write landing page copy for NewStart UK. Audience: international students coming to the UK and organisations supporting newcomers. Tone: trustworthy, practical, warm, plain English. Position NewStart UK as a personalised UK settlement assistant starting with students. Include headline, problem, solution, features, waitlist CTA, partner CTA, and guidance-only disclaimer.
```

# SEO Rule
Every SEO page must help the user do one practical thing better. Avoid content that is broad, generic, or unsupported.
