# Risk Register & Crisis Response Plan

_Operational, compliance, AI, partner, social, and data incident response planning_

**Volume:** Volume 6 - Operations, Pilot & Scale  
**Priority:** High priority  
**Version:** v1.2

# Purpose
This document identifies major risks and defines how NewStart UK should respond to incidents.

# Risk Register
| Risk | Impact | Likelihood | Mitigation |
|---|---|---|---|
| Wrong guidance | User harm, reputation damage | Medium | Source review, disclaimers, human review |
| AI hallucination | Misleading user | Medium | AI guardrails, logs, escalation |
| Data incident | Legal/reputation risk | Low/Medium | Privacy-by-design, access controls |
| Bad partner | User harm, trust loss | Medium | Verification, complaint process |
| Affiliate overclaim | Regulatory/trust risk | Medium | Disclosure and copy review |
| Social backlash | Reputation issue | Medium | Crisis response, factual correction |
| Fake NewStart account | Scam risk | Medium | Verified channels, reporting |
| B2B overpromise | Partner disappointment | Medium | Sales claims must match roadmap |
| Outdated sources | Incorrect guidance | Medium | Source register review |
| Admin misuse | Data/trust risk | Low/Medium | Role permissions and audit logs |

# Crisis Severity
| Level | Example | Response |
|---|---|---|
| Level 1 | Minor typo or content issue | Fix and log |
| Level 2 | User complaint or inaccurate page | Review, correct, notify if needed |
| Level 3 | Bad partner/scam pattern | Suspend listing, investigate, warn users if needed |
| Level 4 | Data incident or harmful advice | Incident response, legal/privacy review, user communication |

# Crisis Response Steps
1. Identify and classify issue.
2. Pause affected feature/content/partner if necessary.
3. Preserve evidence and logs.
4. Assign owner.
5. Draft response using approved tone.
6. Correct issue.
7. Notify affected users/partners if needed.
8. Document root cause.
9. Update processes to prevent repeat.

# Public Response Tone
- calm;
- transparent;
- factual;
- non-defensive;
- user-safety focused;
- no blame shifting;
- no unsupported claims.

# AI Incident Response
If AI gives risky guidance:
- disable or restrict relevant prompt/feature;
- review logs;
- update prompt guardrails;
- add test case;
- notify users only if risk materially affected them.

# Partner Incident Response
If partner is accused of harmful behaviour:
- pause promotion if credible risk;
- gather facts;
- contact partner;
- protect user safety first;
- update verification status;
- remove if unresolved or serious.

# Final Crisis Rule
Speed matters, but accuracy and user protection matter more.
