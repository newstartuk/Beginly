# Privacy, Data Protection & GDPR Readiness

_Data minimisation, consent, retention, AI handling, and B2B privacy boundaries_

**Volume:** Volume 2 - Brand, Trust & Legal Safety  
**Priority:** Pre-coding critical  
**Version:** v1.2

# Purpose
This document defines NewStart UK privacy and data protection principles for MVP planning. It is not a substitute for legal review, but it sets the product direction before coding.

# Privacy Principle
Collect the minimum data needed to generate useful settlement guidance. Avoid collecting or storing sensitive documents until security, legal review, and operational controls are mature.

# MVP Data Categories
| Data | Purpose | Sensitivity | MVP Handling |
|---|---|---|---|
| Name and email | Account and reminders | Personal | Store securely |
| Arrival date/status | Generate stage and reminders | Personal | Store securely |
| City and university | Personalise guidance | Personal | Store securely |
| Accommodation type | Personalise tasks and warnings | Personal | Store securely |
| Nationality | Future insights/personalisation | Sensitive-adjacent | Optional |
| English level | Simplify content | Personal | Optional |
| Task completion | Progress tracking | Behavioural | Store securely |
| Document text snippets | Document Helper | Potentially sensitive | Avoid storage by default; log minimal metadata |
| Uploaded documents | Full vault | Sensitive | Out of MVP scope |

# Document Storage Policy
For MVP v1, use document checklist/vault-lite only.

Allowed:
- users can track whether they have documents;
- users can read document preparation guidance;
- users may paste non-sensitive text for explanation if AI feature is enabled.

Not allowed in MVP v1:
- storing passport images;
- storing visa/BRP images;
- storing bank letters;
- storing full tenancy contracts;
- storing medical letters;
- storing official documents unless security, consent, and retention controls are implemented.

# Consent Requirements
The product should ask for clear consent where relevant:

- email reminders;
- optional nationality or English-level collection;
- AI document helper use;
- analytics cookies beyond essential;
- sharing identifiable progress with a university/partner;
- marketing emails;
- affiliate/partner referrals where tracked.

# B2B Dashboard Privacy
Default B2B reporting should be anonymised and aggregated.

Do not share identifiable user progress with partners unless:
- the user clearly opts in;
- the purpose is specific;
- the user can withdraw consent;
- the partner has appropriate data handling terms.

# Retention Principles
| Data Type | Suggested Retention |
|---|---|
| Account data | Until account deletion or inactivity policy applies |
| Reminder logs | 12 months or less unless needed |
| Task completion data | While account is active |
| AI helper metadata | Short retention; avoid storing full sensitive text |
| Support tickets | Defined retention, with deletion pathway |
| Analytics | Aggregated where possible |

# Admin Access Rules
- Use role-based access.
- Limit access to user data by need.
- Log admin access to sensitive records.
- Avoid exposing raw AI document inputs to general admins.
- Use separate admin roles for content, support, and super admin.

# User Rights Readiness
The app should be designed to support:

- access request;
- correction request;
- deletion request;
- export request;
- marketing opt-out;
- reminder opt-out;
- account closure.

# Privacy-by-Design Checklist
- Do not ask for unnecessary data.
- Make optional fields clearly optional.
- Explain why data is requested.
- Do not store sensitive document uploads in MVP.
- Keep AI logs minimal.
- Separate analytics from identifiable user data where possible.
- Use secure hosting, authentication, and database access controls.

# Final Privacy Rule
If a feature requires sensitive data but does not materially improve the first MVP settlement journey, postpone it.
