# Multilingual & Accessibility Strategy

_Plain English, translation, inclusive UX, and accessibility principles_

**Volume:** Volume 4 - AI, Content & Knowledge Operations  
**Priority:** Medium priority  
**Version:** v1.2

# Purpose
This document defines how NewStart UK should support users with different English confidence levels, accessibility needs, and cultural contexts.

# Core Principle
The MVP should start with clear plain English. Multilingual support should be added carefully so translated content does not distort sensitive guidance.

# Plain-English Rules
- Use short sentences.
- Explain UK-specific terms.
- Avoid jargon.
- Use examples.
- Avoid idioms.
- Put the next step near the top.
- Repeat disclaimers on sensitive pages without overwhelming the user.

# Key Terms to Explain
Examples:
- GP;
- NHS 111;
- council tax;
- student status letter;
- tenancy;
- deposit protection;
- arrears;
- share code;
- right to work;
- National Insurance number;
- full-time student exemption;
- guarantor;
- utilities.

# Accessibility Principles
- Mobile-first responsive design.
- High colour contrast.
- Large tap targets.
- Form labels for screen readers.
- Text alternatives for icons.
- Keyboard navigation.
- Clear error messages.
- Warning icons plus text, not colour alone.
- Avoid flashing or distracting animation.

# Multilingual Roadmap
| Stage | Action |
|---|---|
| MVP | Plain English and key term explanations |
| MVP+ | Translate key terms and short summaries |
| Phase 2 | Add language-specific guide summaries |
| Phase 3 | Community-reviewed translations for priority languages |

# Translation Safety
Translated content must preserve:
- disclaimer meaning;
- eligibility uncertainty;
- source signposting;
- warning tone;
- no-guarantee language.

# Priority Language Selection
Choose languages based on:
- user signups;
- university intake patterns;
- support ticket demand;
- ambassador availability;
- community partner input.

# Inclusive Design
NewStart UK should not assume users:
- know UK systems;
- have strong English;
- have permanent accommodation;
- have stable income;
- understand local abbreviations;
- are comfortable asking institutions for help.

# Final Accessibility Rule
A user should be able to understand their next step even if they are tired, anxious, on a phone, and reading in a second language.
