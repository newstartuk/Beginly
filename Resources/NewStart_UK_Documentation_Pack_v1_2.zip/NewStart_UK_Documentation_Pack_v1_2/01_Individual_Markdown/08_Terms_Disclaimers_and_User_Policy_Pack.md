# Terms, Disclaimers & User Policy Pack

_Draft user-facing policy structure and required disclaimers_

**Volume:** Volume 2 - Brand, Trust & Legal Safety  
**Priority:** Policy draft  
**Version:** v1.2

# Purpose
This document provides the user-facing policy structure for NewStart UK. It is a drafting foundation and should be reviewed by a qualified professional before public launch.

# Policy Documents Needed
NewStart UK should prepare:

1. Terms of Use.
2. Privacy Policy.
3. Cookie Policy.
4. AI Use Disclaimer.
5. Affiliate and Partner Disclosure.
6. Support Limitation Policy.
7. Community Guidelines, if community features launch.
8. Refund Policy, if paid plans launch.

# Master Disclaimer
"NewStart UK provides general settlement guidance, checklist support, document explanation, and signposting. We do not provide legal, immigration, financial, tax, medical, or housing advice. For official or regulated matters, please use official sources or speak to a qualified professional."

# AI Disclaimer
"Some NewStart UK features may use AI to simplify wording, explain general concepts, draft checklist-style guidance, or suggest next steps. AI outputs may be incomplete or inaccurate and should not be treated as official advice. Sensitive decisions should be checked with official sources or qualified professionals."

# Affiliate Disclosure
"Some providers may pay NewStart UK a referral fee or commission. We only aim to recommend services that match user needs, and users remain free to choose another provider. Paid relationships do not make a provider official or guaranteed."

# Partner Disclaimer
"NewStart UK may list or signpost partner services. Unless clearly stated, partners are independent organisations. Users should review terms, pricing, eligibility, and suitability before using any external service."

# Support Limitation Wording
"NewStart UK support can help explain how to use the platform and understand general settlement steps. We cannot make legal, immigration, financial, medical, tax, or housing decisions for users."

# Terms of Use Outline
- Acceptance of terms.
- Service description.
- Account registration.
- User responsibilities.
- Guidance-only limitation.
- AI feature limitations.
- Prohibited misuse.
- External links and partners.
- Paid services, if applicable.
- Changes to service.
- Liability limitations.
- Termination.
- Contact information.

# Privacy Policy Outline
- Who controls the data.
- What data is collected.
- Why data is collected.
- Legal basis to process data.
- How long data is stored.
- Who data may be shared with.
- AI and analytics processing.
- User rights.
- Security measures.
- Contact route.

# Community Guidelines Outline
If social/community features launch, users must not:

- post scams;
- offer fake jobs or accommodation;
- request payment outside approved channels;
- impersonate officials;
- harass users;
- give regulated advice while posing as an expert;
- share another person's private documents.

# Launch Rule
Do not launch paid, AI, partner, community, or document-helper features publicly until the relevant policy wording is visible and aligned with actual product behaviour.
