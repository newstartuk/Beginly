# Customer Support & Escalation SOP

_Support categories, response templates, escalation routes, and sensitive issue handling_

**Volume:** Volume 6 - Operations, Pilot & Scale  
**Priority:** High priority  
**Version:** v1.2

# Purpose
This document defines how NewStart UK should respond to user questions, concerns, and support tickets.

# Support Principle
Support should be helpful, calm, and clear while respecting the boundary between general guidance and regulated advice.

# Support Categories
| Category | Examples | Default Action |
|---|---|---|
| Account | Login, password, profile | Technical support |
| Checklist | Task confusion, progress issue | Explain feature/guidance |
| Documents | Form/letter confusion | Explain generally, signpost if sensitive |
| Housing | Deposit, landlord, contract | Scam warning + signpost, no legal advice |
| Health | GP/NHS questions | General signposting, no diagnosis |
| Work | CV, NI, right-to-work awareness | General guidance, official signposting |
| Council tax | Student exemption/letters | General explanation, signpost council/university |
| Partner complaint | Bad service | Escalate internally |
| Scam concern | Fake job/landlord/payment | High priority support |
| Payment/refund | Subscription later | Billing support |

# Response Template
1. Acknowledge the issue.
2. Provide general guidance or product help.
3. State limitation if sensitive.
4. Signpost official/qualified support.
5. Offer the next safe step.
6. Log category and escalation if needed.

# Escalation Triggers
Escalate to human review when:
- potential fraud/scam is reported;
- user may lose housing;
- formal legal/council/immigration letter is involved;
- health urgency is mentioned;
- user reports abuse, threats, exploitation, or distress;
- partner complaint is serious;
- AI produced a questionable response;
- user asks for regulated advice.

# Standard Sensitive Reply
"I can help explain the general meaning and suggest safe next steps, but NewStart UK cannot provide legal, immigration, financial, tax, medical, or housing advice. For this issue, please check the official source or speak to a qualified professional."

# Partner Complaint Process
1. Acknowledge complaint.
2. Record partner, issue, evidence if provided.
3. Do not promise outcome.
4. Escalate internally.
5. Pause partner promotion if risk is serious.
6. Follow up with user where appropriate.

# Scam Concern Process
1. Advise user not to send more money/details.
2. Encourage saving evidence.
3. Signpost official reporting/support routes.
4. Log scam type.
5. Add content warning if pattern repeats.

# Support Metrics
- tickets by category;
- response time;
- escalations;
- repeated issues;
- unresolved tickets;
- partner complaints;
- content gaps discovered.

# Final Support Rule
When in doubt, do not improvise sensitive advice. Explain the boundary and signpost safely.
