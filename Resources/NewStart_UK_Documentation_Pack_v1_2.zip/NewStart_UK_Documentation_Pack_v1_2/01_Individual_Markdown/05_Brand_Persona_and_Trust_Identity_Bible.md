# Brand, Persona & Trust Identity Bible

_Brand voice, Nia/NewStart Navigator, avatar rules, and trust identity_

**Volume:** Volume 2 - Brand, Trust & Legal Safety  
**Priority:** Pre-coding critical  
**Version:** v1.2

# Purpose
This document defines how NewStart UK should feel, speak, behave, and show up publicly. It governs the brand voice, persona, avatar use, human trust layer, and public-facing tone.

# Brand Essence
NewStart UK should feel like a calm, practical, protective companion for people starting life in the UK.

## Brand Promise
We help you know what to do next.

## Brand Personality
| Trait | Meaning |
|---|---|
| Calm | Avoid panic, fear, and alarmist wording |
| Practical | Give clear next steps, not vague motivation |
| Protective | Warn users about scams and costly mistakes |
| Respectful | Do not patronise newcomers |
| Plain-English | Make unfamiliar systems understandable |
| Trust-first | Never sacrifice user safety for growth or revenue |
| Modern | Feel digital, clean, and mobile-first |

# Brand Voice Rules
Use language that is:

- simple but not childish;
- reassuring but not overpromising;
- warm but not casual to the point of unseriousness;
- practical and action-oriented;
- culturally sensitive;
- compliance-aware.

## Avoid
- "Guaranteed" outcomes.
- Fearmongering.
- Fake urgency.
- Pretending to be official government, NHS, university, or legal authority.
- Overusing AI hype.
- Complex legal or bureaucratic language unless explained.

# Corporate Persona
The recommended persona is:

## Nia - The NewStart Navigator
Nia is an AI-assisted guide created by NewStart UK to provide general settlement guidance, checklist support, document explanation, and next-step suggestions.

Nia can appear in:
- app onboarding;
- checklist prompts;
- email reminders;
- short explainer videos;
- Document Helper Lite;
- social media content;
- support triage messages.

# Persona Disclosure
Use this disclosure wherever appropriate:

"Nia is an AI-assisted guide created by NewStart UK to provide general settlement guidance and checklist support. Nia does not provide legal, immigration, financial, tax, medical, or housing advice."

# Avatar and Digital Twin Rules
AI avatars may be used for scalable education, but must not be deceptive.

| Allowed | Not Allowed |
|---|---|
| Clearly labelled AI guide | Fake founder or fake adviser |
| General explainers | Legal/immigration/medical advice delivery |
| Checklist reminders | Pretending to have lived experience |
| Social video presenter | Pretending to be a student or government official |
| Multilingual guidance summaries | Undisclosed sponsored recommendations |

# Human Trust Layer
NewStart UK should not rely on AI persona alone. It should include:

- founder/operations voice;
- student ambassadors;
- community partners;
- verified partner organisations;
- real testimonials where consent is given;
- human escalation for sensitive support issues.

# Trust Signals
Use trust signals consistently:

- "general guidance, not regulated advice";
- source-backed guidance;
- partner verification;
- clear affiliate disclosure;
- privacy-first design;
- human escalation where needed;
- user control over data.

# Brand Copy Examples
| Context | Preferred Copy |
|---|---|
| Dashboard greeting | Welcome back. Here are the next steps that matter most today. |
| Risk warning | Before you pay a deposit, check the provider and keep written evidence. |
| Sensitive guidance | This is general guidance only. For official advice, use the relevant official source or a qualified professional. |
| Completion | Good progress. You have completed another important step in your settlement journey. |

# Final Brand Rule
NewStart UK should feel like trusted arrival support - not a gimmick, not a fake adviser, and not a hard-selling marketplace.
