# Source Library & Official Reference Register

_Official source tracking, review dates, content ownership, and evidence rules_

**Volume:** Volume 4 - AI, Content & Knowledge Operations  
**Priority:** High priority  
**Version:** v1.2

# Purpose
This document controls source quality. NewStart UK must not rely on memory or outdated assumptions for sensitive guidance.

# Source Principle
When guidance touches official processes, rights, obligations, healthcare, work, documents, housing, or finance, it should be linked to an official or reputable source and reviewed regularly.

# Source Categories
| Category | Preferred Sources |
|---|---|
| Immigration/eVisa/share code | GOV.UK |
| Right to work | GOV.UK |
| GP/NHS | NHS official pages |
| Council tax | UKCISA, local council, GOV.UK where relevant |
| Housing/deposit | GOV.UK, Shelter, local council guidance |
| Student guidance | University official pages, UKCISA |
| Banking | Bank official pages, neutral FCA-style sources where relevant |
| Jobs/scams | GOV.UK, Action Fraud, university careers pages |
| Local services | Official council/university/local provider pages |

# Source Register Fields
| Field | Description |
|---|---|
| source_id | Stable source ID |
| title | Source title |
| organisation | GOV.UK, NHS, UKCISA, university, council, etc. |
| URL | Official link |
| topic | GP, housing, bank, council tax, etc. |
| used_in | Guidance pages/tasks using this source |
| last_checked | Date last verified |
| next_review | Date to recheck |
| owner | Person/team responsible |
| risk_level | Low, Medium, High |
| notes | Summary of relevance |

# Review Frequency
| Risk Level | Review Frequency |
|---|---|
| High | Monthly or whenever rules change |
| Medium | Quarterly |
| Low | Twice yearly |

# High-Risk Topics
Mark these high risk:
- visa/eVisa/share code;
- right to work;
- council tax;
- GP/NHS eligibility/access;
- tenancy/deposit;
- NI number;
- scams/fraud;
- financial products;
- employment restrictions.

# Source Use Rules
- Do not copy long text from sources.
- Paraphrase in plain English.
- Link/signpost to official source.
- Include last-reviewed date on sensitive guidance pages.
- If source is unclear, label content for human review.

# Outdated Source Process
If a source may be outdated:
1. Unpublish or flag the affected guidance.
2. Add "review required" status.
3. Replace with official updated source.
4. Log update in content operations.
5. Notify affected admins/support if relevant.

# Final Source Rule
Accuracy is part of the product. A beautifully designed app with outdated guidance is a trust risk.
