# Pilot & Validation Playbook

_User research, partner validation, prototype tests, success metrics, and decision gates_

**Volume:** Volume 6 - Operations, Pilot & Scale  
**Priority:** High priority  
**Version:** v1.2

# Purpose
This document defines how NewStart UK should validate demand before heavy build or scale.

# Validation Goal
Prove that newcomers and partner organisations experience the settlement problem strongly enough to use or pay for NewStart UK.

# Validation Audiences
Interview:
- 10 international students already in the UK;
- 10 incoming students;
- 3 education agents;
- 2 university/student support staff;
- 2 accommodation providers;
- 2 employers/recruiters or care recruiters;
- 2 community/church/student society leaders.

# Student Interview Questions
1. What confused you most before arrival?
2. What confused you most in your first week?
3. What cost you money or time?
4. Which tasks were hardest: bank, GP, housing, council tax, SIM, transport, jobs, documents?
5. What did your university/agent explain well?
6. What did they not explain well?
7. Would a 90-day personalised checklist have helped?
8. Would reminders have helped?
9. Would you pay £9.99, £24.99, or £49 for different levels of support?
10. Would you trust AI document explanation if clearly limited?

# Partner Discovery Questions
1. How do you currently support newcomers?
2. What repeated questions create workload?
3. Which arrival problems cause the most complaints?
4. Would a structured onboarding portal help?
5. What would you pay for a pilot?
6. What anonymised insights would be useful?
7. What would make you trust the platform?
8. Would you pilot with 50-500 users?

# Prototype Test Tasks
Ask users to:
- sign up;
- complete onboarding;
- view dashboard;
- find top three tasks;
- open a guide;
- mark a task complete;
- review Document Helper concept.

# Pilot Structure
## Student Pilot
- 50-100 users.
- 30 days.
- Free or low-cost beta.
- Weekly feedback.

## Partner Pilot
- one agent/community/university/accommodation partner;
- 100-500 users if available;
- anonymised summary report;
- testimonial/case study if successful.

# Success Metrics
| Metric | Strong Signal |
|---|---|
| Onboarding completion | 70%+ |
| Users completing 3+ tasks | 60%+ |
| Return within 7 days | 30%+ |
| Users saying it reduced stress/confusion | 70%+ |
| Willingness to pay | 20%+ show paid interest |
| Partner pilot interest | 3+ serious leads |

# Decision Gates
After pilot, decide:
- continue student-only or add worker/family segment;
- launch paid plan or remain beta;
- prioritise B2C or B2B;
- build AI helper now or later;
- add WhatsApp reminders or keep email first.

# Validation Rule
Do not scale features until users repeatedly return because NewStart helps them know what to do next.
