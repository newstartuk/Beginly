# Vibe Coding Build Spec v1.0

_Technical stack, routes, schema, components, APIs, sprints, and acceptance criteria_

**Volume:** Volume 3 - UX, Build & Technical Delivery  
**Priority:** Pre-coding critical  
**Version:** v1.2

# Purpose
This is the primary developer-facing build document. It should be given to a coding agent or developer before starting implementation.

# Recommended Stack
| Layer | Recommendation |
|---|---|
| Frontend | Next.js App Router |
| Styling | Tailwind CSS + shadcn/ui |
| Auth | Supabase Auth |
| Database | Supabase Postgres |
| Email | Resend |
| AI | OpenAI-compatible API later |
| Hosting | Vercel |
| Storage | Supabase Storage later, not MVP v1 for sensitive docs |
| Payments | Stripe later, not MVP v1 |

# Core App Routes
| Route | Purpose |
|---|---|
| / | Landing page |
| /signup | User registration |
| /login | Login |
| /onboarding | Arrival profile setup |
| /dashboard | Student dashboard |
| /checklist | Checklist list and filters |
| /tasks/[id] | Task detail |
| /guides | Guidance library |
| /guides/[slug] | Guidance article |
| /document-helper | Document Helper Lite beta/placeholder |
| /settings | Reminder/profile settings |
| /support | Support/contact |
| /admin | Admin dashboard |
| /admin/tasks | Task template manager |
| /admin/guides | Guidance content manager |
| /admin/users | User overview |

# Recommended Folder Structure
```text
/app
  /(public)
  /(auth)
  /(student)
  /admin
/components
  /ui
  /dashboard
  /checklist
  /guidance
  /admin
/lib
  supabase.ts
  checklist-engine.ts
  readiness-score.ts
  reminders.ts
  permissions.ts
/data
  seed-tasks.json
  seed-guides.json
/types
  index.ts
```

# Database Tables
Minimum MVP tables:

- profiles
- arrival_profiles
- checklist_tasks
- user_tasks
- guidance_pages
- reminders
- scam_alerts
- admin_users
- support_tickets
- event_logs

Future tables:
- partners
- partner_categories
- subscriptions
- payments
- organisation_accounts
- cohorts
- ai_interactions

# Core Build Sequence
## Sprint 1 - Foundation
- Create Next.js app.
- Configure Tailwind and shadcn/ui.
- Set up Supabase Auth.
- Create landing page.
- Create login/signup.
- Create protected dashboard shell.

## Sprint 2 - Onboarding
- Build onboarding profile form.
- Save arrival profile.
- Calculate journey stage from arrival date/status.
- Redirect user to dashboard.

## Sprint 3 - Checklist Engine
- Create checklist seed data.
- Generate user_tasks from checklist_tasks.
- Build checklist page.
- Build task detail page.
- Mark complete/in progress/not started.
- Calculate readiness score.

## Sprint 4 - Guidance and Warnings
- Create guidance library.
- Link tasks to guides.
- Add scam alert cards.
- Add disclaimer components.

## Sprint 5 - Admin MVP
- Admin role check.
- Task template CRUD.
- Guidance page CRUD.
- Basic user/task analytics.

## Sprint 6 - Reminders and Polish
- Reminder preferences.
- Email reminder records.
- Resend integration.
- Mobile UI polish.
- QA and deployment.

# API/Action Requirements
Use server actions or API routes for:

- create/update arrival profile;
- generate checklist;
- update user task status;
- fetch dashboard summary;
- admin create/update task template;
- admin create/update guide;
- create support ticket;
- send reminder email.

# MVP Acceptance Criteria
- User can sign up and log in.
- User can complete onboarding.
- User receives tasks based on arrival stage and profile.
- User can mark tasks complete.
- Dashboard readiness score updates.
- Task detail pages show guidance, warnings, and disclaimer.
- Admin can edit task templates and guidance.
- App is usable on mobile.
- No sensitive document upload is required.
- No feature claims to provide regulated advice.

# Vibe Coding Master Instruction
Build the MVP in disciplined phases. Do not add future features unless explicitly requested. Prioritise clean data models, mobile-first UX, safe copy, and editable admin content.
