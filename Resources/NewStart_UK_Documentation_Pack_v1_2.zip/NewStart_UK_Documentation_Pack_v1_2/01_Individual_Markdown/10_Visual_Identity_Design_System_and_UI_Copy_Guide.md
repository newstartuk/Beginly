# Visual Identity, Design System & UI Copy Guide

_Brand look, interface language, components, and design-generation prompts_

**Volume:** Volume 3 - UX, Build & Technical Delivery  
**Priority:** Pre-coding critical  
**Version:** v1.2

# Purpose
This document defines how NewStart UK should look and sound in product interfaces, PDFs, landing pages, social content, and future mobile/PWA screens.

# Design Direction
NewStart UK should feel like modern civic-tech plus friendly student support plus calm fintech-style dashboard.

It should not feel like:
- a government clone;
- a childish student app;
- an AI gimmick;
- a hard-selling affiliate site;
- a legal advisory service.

# Visual Personality
| Attribute | Direction |
|---|---|
| Calm | Soft backgrounds, clear spacing, non-alarmist warnings |
| Trustworthy | Structured layouts, source notes, restrained colour use |
| Helpful | Checklist cards, next-step guidance, progress indicators |
| Human | Warm illustrations or avatar use, not cold dashboards only |
| Modern | Rounded cards, clean typography, responsive mobile interface |

# Suggested Colour Tokens
| Token | Use | Suggested Hex |
|---|---|---|
| primary | Main buttons, active states | #0B7285 |
| primary_dark | Headers, trust anchors | #102A43 |
| accent | Highlights, progress | #2F9E44 |
| warning | Caution cards | #F08C00 |
| danger | Serious warnings | #C92A2A |
| background | App background | #F8FAFC |
| card | Cards/panels | #FFFFFF |
| border | Dividers | #D9E2EC |
| muted_text | Secondary text | #627D98 |

# Typography Direction
Use a clean sans-serif system. Recommended web stack:

- Inter, Geist, or system-ui.
- Clear hierarchy.
- Avoid decorative fonts.
- Body copy should be easy to read on mobile.

# Component Library
Core components:
- primary button;
- secondary button;
- checklist card;
- task detail card;
- warning card;
- guidance article card;
- readiness score widget;
- stage progress tracker;
- reminder settings panel;
- document helper panel;
- admin table;
- empty state;
- success message;
- source/disclaimer box.

# UI Copy Style
Use action-oriented copy.

| Context | Good Copy |
|---|---|
| Dashboard heading | Your next steps for today |
| Empty tasks | You are up to date for this stage. Review upcoming tasks. |
| Warning | Before paying a deposit, check the provider and keep written evidence. |
| Completion | Task completed. Your readiness score has been updated. |
| Document Helper | Paste non-sensitive text you want explained in plain English. |
| Disclaimer | This is general guidance, not regulated advice. |

# Accessibility Principles
- Maintain colour contrast.
- Do not rely on colour alone to show warning states.
- Use large tap targets.
- Use simple language.
- Ensure screen reader labels on forms.
- Make progress visible in text and graphics.
- Keep PDF exports readable in black and white.

# PDF Style Direction
Documentation PDFs should use:
- clean cover page;
- consistent footer;
- clear section hierarchy;
- readable tables;
- callout boxes;
- restrained colour accents;
- page numbers;
- document version and date.

# Design Generation Prompt
Use this prompt when asking an AI design tool to generate screens:

```text
Design a mobile-first NewStart UK screen using a calm civic-tech + friendly student support + fintech dashboard style. Use soft backgrounds, rounded cards, clear hierarchy, plain-English microcopy, and trust-first visual language. The product helps international students settle into the UK through personalised checklists, reminders, guidance, and scam-prevention alerts. Do not make it look like a government website, a childish student game, or an AI gimmick. Include visible but subtle guidance-only disclaimer where the screen touches sensitive topics.
```

# Final Design Rule
Clarity is more important than decoration. Users should always know what to do next.
