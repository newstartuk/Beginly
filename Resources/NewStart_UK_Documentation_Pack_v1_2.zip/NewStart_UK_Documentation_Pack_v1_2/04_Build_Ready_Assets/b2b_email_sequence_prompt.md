# B2B Email Sequence Prompt
Write a 4-email outreach sequence for NewStart UK targeting [segment]. Tone: professional, concise, helpful. Emphasise reducing newcomer confusion, structured onboarding, personalised checklists, reminders, and anonymised insights. Include a pilot CTA. Do not overpromise. Do not imply NewStart replaces official support or provides regulated advice.
