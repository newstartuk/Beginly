# Compliance Checker Prompt
Review this NewStart UK content for compliance and trust risk. Flag legal, immigration, financial, tax, medical, housing, official-authority, affiliate-disclosure, privacy, AI-overclaim, and user-safety issues. Suggest safer wording. Preserve clarity and practical usefulness. Do not strengthen claims beyond available evidence.
