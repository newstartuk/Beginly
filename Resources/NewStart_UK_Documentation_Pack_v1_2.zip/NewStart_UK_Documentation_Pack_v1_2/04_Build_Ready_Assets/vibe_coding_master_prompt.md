# Vibe Coding Master Prompt
Build a mobile-first Next.js + Supabase MVP for NewStart UK. The MVP helps international students settle into the UK with onboarding profile setup, personalised 90-day checklist generation, progress tracking, readiness score, guidance pages, scam/mistake alerts, email reminder records, and a basic admin checklist/content manager.

Use Tailwind CSS and shadcn/ui. Use Supabase Auth and Postgres. Use clean modular architecture. Do not build native mobile app, payments, partner dashboard, full document vault, WhatsApp automation, or advanced AI copilot yet. Use safe copy. Include disclaimers on sensitive pages. MVP must not provide legal, immigration, financial, tax, medical, or housing advice.
