# Lead Magnet Generation Prompt
Create a downloadable lead magnet for NewStart UK titled: [title]. Audience: [audience]. Include a practical checklist, short explanations, common mistakes, and a final CTA to join NewStart UK. Use plain English. Include guidance-only disclaimer if the topic touches documents, housing, work, health, money, council tax, or immigration status.
