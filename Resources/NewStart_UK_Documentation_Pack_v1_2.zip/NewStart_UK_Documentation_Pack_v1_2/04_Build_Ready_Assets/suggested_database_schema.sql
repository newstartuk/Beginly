-- NewStart UK MVP suggested schema
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  email text,
  role text default 'student',
  created_at timestamptz default now()
);

create table arrival_profiles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  arrival_type text default 'student',
  arrival_status text,
  arrival_date date,
  city text,
  university text,
  accommodation_type text,
  nationality text,
  english_level text,
  interested_in_work boolean default false,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create table checklist_tasks (
  id uuid primary key default gen_random_uuid(),
  task_id text unique not null,
  title text not null,
  stage text not null,
  category text not null,
  priority text not null,
  required boolean default true,
  condition text,
  dependency_ids text[],
  reminder_trigger text,
  guidance_slug text,
  risk_warning text,
  source_required boolean default false,
  ai_helper_allowed boolean default false,
  escalation_flag boolean default false,
  active boolean default true,
  created_at timestamptz default now()
);

create table user_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete cascade,
  checklist_task_id uuid references checklist_tasks(id),
  status text default 'not_started',
  due_date date,
  completed_at timestamptz,
  created_at timestamptz default now()
);

create table guidance_pages (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  title text not null,
  category text,
  body text,
  disclaimer_required boolean default false,
  source_review_required boolean default false,
  last_reviewed_at date,
  published boolean default false,
  created_at timestamptz default now()
);

create table support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references profiles(id) on delete set null,
  category text,
  subject text,
  message text,
  status text default 'open',
  priority text default 'normal',
  created_at timestamptz default now()
);
