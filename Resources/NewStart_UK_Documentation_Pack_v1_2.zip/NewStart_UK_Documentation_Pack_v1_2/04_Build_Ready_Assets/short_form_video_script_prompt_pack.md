# Short-Form Video Script Prompt
Write a 30-45 second video script for NewStart UK on: [topic]. Hook the viewer with a real newcomer pain point. Explain 3 practical points. End with one safe next step and a CTA to join NewStart UK. Tone: calm, protective, practical. Avoid fearmongering. Include guidance-only boundary if the topic is sensitive.
