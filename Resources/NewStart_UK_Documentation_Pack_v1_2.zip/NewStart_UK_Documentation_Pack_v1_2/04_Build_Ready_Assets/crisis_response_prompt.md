# Crisis Response Prompt
Draft a calm, transparent response for NewStart UK about [incident]. Tone: factual, user-safety focused, non-defensive. Acknowledge concern, state what is being reviewed, explain immediate action, avoid blame, avoid unsupported claims, and provide next steps. Do not reveal private user information.
