# Social Media Content Prompt Pack
Create social content for NewStart UK. Audience: [incoming students/current students/parents/agents/universities]. Topic: [topic]. Tone: calm, practical, protective, plain English. Include one clear next step, one mistake to avoid, and a soft CTA to join the waitlist or download a checklist. Do not provide legal, immigration, financial, tax, medical, or housing advice. Do not make guaranteed claims.

Formats to generate: short video script, caption, carousel outline, story poll, and CTA.
