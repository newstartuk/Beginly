# NewStart UK Documentation Pack v1.2

Version: v1.2  
Date: May 2026

## Contents

This pack contains 28 Markdown source files, 28 individual PDFs, 6 merged volume PDFs, 1 complete master PDF, and build-ready assets/prompts.

## Document List

01. **Strategic Blueprint v1.2** - Vision, positioning, market logic, expansion path, and strategic guardrails  
02. **Product Strategy & MVP Definition v1.2** - Locked MVP scope, exclusions, release boundaries, and success metrics  
03. **Student Settlement Checklist & Task Logic v1.2** - Structured 90-day journey, task fields, reminders, dependencies, and scoring  
04. **Master Documentation Architecture** - Document hierarchy, source-of-truth rules, volumes, and update control  
05. **Brand, Persona & Trust Identity Bible** - Brand voice, Nia/NewStart Navigator, avatar rules, and trust identity  
06. **Trust, Safety & Compliance Playbook** - Boundaries for sensitive guidance, disclaimers, escalation, and safety controls  
07. **Privacy, Data Protection & GDPR Readiness** - Data minimisation, consent, retention, AI handling, and B2B privacy boundaries  
08. **Terms, Disclaimers & User Policy Pack** - Draft user-facing policy structure and required disclaimers  
09. **UX Journey & Screen Map** - User, admin, support, and future partner journeys  
10. **Visual Identity, Design System & UI Copy Guide** - Brand look, interface language, components, and design-generation prompts  
11. **Vibe Coding Build Spec v1.0** - Technical stack, routes, schema, components, APIs, sprints, and acceptance criteria  
12. **Checklist Rules Engine & Seed Data Spec** - Task-generation conditions, sample JSON, readiness formula, and fallback logic  
13. **Analytics, Events & Product Metrics Spec** - Event tracking, privacy-safe metrics, dashboards, and product intelligence  
14. **QA, Testing & Acceptance Criteria Manual** - Feature tests, compliance tests, AI tests, mobile checks, and release gates  
15. **Deployment, DevOps & Environment Setup Guide** - Hosting, environment variables, migrations, monitoring, backups, and release checklist  
16. **AI Governance & Prompt Manual** - Document Helper, admin AI, compliance checker, refusal rules, and prompt templates  
17. **Content & Knowledge Base Operations Manual** - Guidance pages, city packs, university packs, review workflows, and content templates  
18. **Source Library & Official Reference Register** - Official source tracking, review dates, content ownership, and evidence rules  
19. **Multilingual & Accessibility Strategy** - Plain English, translation, inclusive UX, and accessibility principles  
20. **Social Media, Acquisition & Community Growth Engine** - Content-led growth, Hormozi-style loop, channel strategy, and launch calendar  
21. **SEO, Landing Page & Lead Magnet Strategy** - Search content, conversion pages, downloadable assets, and waitlist funnel  
22. **Commercial, Partner & Revenue Operations Framework** - B2C, B2B, affiliate, premium support, partner verification, and pricing logic  
23. **Ambassador, Referral & Community Programme** - Student ambassadors, referral loops, community rules, and testimonial strategy  
24. **Pilot & Validation Playbook** - User research, partner validation, prototype tests, success metrics, and decision gates  
25. **Customer Support & Escalation SOP** - Support categories, response templates, escalation routes, and sensitive issue handling  
26. **Admin Operations Manual** - Internal routines for content, users, checklist updates, AI review, partners, and reporting  
27. **Risk Register & Crisis Response Plan** - Operational, compliance, AI, partner, social, and data incident response planning  
28. **B2B Sales, Proposal & Account Management Playbook** - University, agent, employer, accommodation, and partner sales workflows  

## Recommended Starting Order for Vibe Coding

1. Product Strategy & MVP Definition v1.2
2. Student Settlement Checklist & Task Logic v1.2
3. Brand, Persona & Trust Identity Bible
4. Trust, Safety & Compliance Playbook
5. Privacy, Data Protection & GDPR Readiness
6. UX Journey & Screen Map
7. Visual Identity, Design System & UI Copy Guide
8. Vibe Coding Build Spec v1.0
9. Checklist Rules Engine & Seed Data Spec
10. QA, Testing & Acceptance Criteria Manual

## Operating Rule
Do not let growth override trust. Do not let AI override compliance. Do not let design override clarity. Do not let B2B promises exceed the MVP.
